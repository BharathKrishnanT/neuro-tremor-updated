import { jsPDF } from 'jspdf';
import autoTable, { applyPlugin } from 'jspdf-autotable';
import { Session } from '../App';
import { format } from 'date-fns';

// Ensure the plugin is applied to jsPDF prototype if needed
try {
  applyPlugin(jsPDF);
} catch {
  // Ignore if already applied
}

export interface PatientDetails {
  fullName: string;
  patientId: string;
  age: string | number;
  gender: string;
  dominantHand: string;
  clinicianName: string;
  assessmentDate: string;
  medicationStatus?: string;
  notes?: string;
}

export const generateClinicalReport = (session: Session, patient?: PatientDetails) => {
  const doc = new jsPDF();
  const dateStr = patient?.assessmentDate || format(session.timestamp, 'yyyy-MM-dd HH:mm:ss');
  
  // Safe filename with patient name if provided
  const sanitizedName = patient?.fullName 
    ? patient.fullName.replace(/[^a-zA-Z0-9]/g, '_').slice(0, 20) 
    : 'Patient';
  const fileName = `NeuroTremor_Report_${sanitizedName}_${format(session.timestamp, 'yyyyMMdd_HHmm')}.pdf`;

  // Top Hospital / Clinic Branding Bar
  doc.setFillColor(15, 23, 42); // Slate 900
  doc.rect(0, 0, 210, 22, 'F');
  
  doc.setFontSize(14);
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.text('NEUROLOGY & MOVEMENT DISORDERS CLINIC', 14, 11);

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(148, 163, 184); // Slate 400
  doc.text('Objective Tremor Biomarker Assessment & Quantitative Motion Report', 14, 17);

  // Subheader Info
  let currentY = 30;
  doc.setFontSize(9);
  doc.setTextColor(100);
  doc.text(`Report ID: ${session.id}`, 14, currentY);
  doc.text(`Generated: ${format(new Date(), 'yyyy-MM-dd HH:mm:ss')}`, 130, currentY);
  currentY += 6;

  // Section 1: Patient Details Table
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text('1. Patient Demographics & Clinical Profile', 14, currentY);
  doc.setDrawColor(203, 213, 225);
  doc.setLineWidth(0.5);
  doc.line(14, currentY + 2, 196, currentY + 2);
  currentY += 5;

  const patientTableBody = [
    [
      { content: 'Patient Name:', styles: { fontStyle: 'bold' as const } },
      patient?.fullName || 'Anonymous / Unspecified',
      { content: 'Patient ID / MRN:', styles: { fontStyle: 'bold' as const } },
      patient?.patientId || 'MRN-RECORD'
    ],
    [
      { content: 'Age / Gender:', styles: { fontStyle: 'bold' as const } },
      `${patient?.age || 'N/A'} / ${patient?.gender || 'Unspecified'}`,
      { content: 'Dominant Hand:', styles: { fontStyle: 'bold' as const } },
      patient?.dominantHand || 'Right'
    ],
    [
      { content: 'Assessment Date:', styles: { fontStyle: 'bold' as const } },
      dateStr,
      { content: 'Medication State:', styles: { fontStyle: 'bold' as const } },
      patient?.medicationStatus || 'N/A'
    ],
    [
      { content: 'Attending Clinician:', styles: { fontStyle: 'bold' as const } },
      patient?.clinicianName || 'Attending Physician',
      { content: 'Referral Reason / Notes:', styles: { fontStyle: 'bold' as const } },
      patient?.notes ? patient.notes.slice(0, 50) + (patient.notes.length > 50 ? '...' : '') : 'Standard quantitative tremor evaluation'
    ]
  ];

  autoTable(doc, {
    startY: currentY,
    body: patientTableBody,
    theme: 'plain',
    styles: { fontSize: 9, cellPadding: 2, textColor: [30, 41, 59] },
    columnStyles: {
      0: { cellWidth: 35, textColor: [71, 85, 105] },
      1: { cellWidth: 60 },
      2: { cellWidth: 35, textColor: [71, 85, 105] },
      3: { cellWidth: 55 }
    }
  });

  currentY = ((doc as any).lastAutoTable?.finalY ?? currentY + 25) + 6;

  // Section 2: Sensor Recording & Methodology
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text('2. Sensor Methodology & Acquisition', 14, currentY);
  doc.setLineWidth(0.5);
  doc.line(14, currentY + 2, 196, currentY + 2);
  currentY += 5;

  const estimatedHz = session.duration > 0 ? Math.round(session.data.length / session.duration) : 200;
  const isPen = session.data[0]?.fsr > 0;

  const recordingData = [
    ['Acquisition Hardware', isPen ? 'Smart Neuro-Pen (9-Axis IMU + Force Grip FSR)' : 'Mobile Kinematic Sensor (Tri-axial Accel + Gyro)'],
    ['Recording Duration', `${session.duration.toFixed(2)} seconds`],
    ['Total Sensor Samples', `${session.data.length} data frames (~${estimatedHz} Hz sampling rate)`],
    ['Sensor Calibration', 'Zero-offset baseline compensation applied']
  ];

  autoTable(doc, {
    startY: currentY,
    head: [['Acquisition Metric', 'Hardware Parameter']],
    body: recordingData,
    theme: 'striped',
    headStyles: { fillColor: [71, 85, 105], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 9 },
    bodyStyles: { fontSize: 8.5, textColor: [30, 41, 59] }
  });

  currentY = ((doc as any).lastAutoTable?.finalY ?? currentY + 25) + 6;

  // Section 3: Quantitative Tremor Biomarkers
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text('3. Objective Tremor Biomarkers & Quantitative Analysis', 14, currentY);
  doc.setLineWidth(0.5);
  doc.line(14, currentY + 2, 196, currentY + 2);
  currentY += 5;

  const freqBand = session.frequency >= 3.5 && session.frequency <= 6.5
    ? 'Parkinsonian Frequency Band (3.5 - 6.5 Hz)'
    : session.frequency > 6.5 && session.frequency <= 12
    ? 'Essential / Postural Tremor Band (6.5 - 12.0 Hz)'
    : 'Normal Physiological / Baseline (< 3.5 Hz)';

  const findingsData = [
    ['Tremor Severity Score', session.severity, 'Calculated ML tremor intensity score (0 - 4 scale)'],
    ['Clinical Classification Stage', session.stage, 'Staged based on composite amplitude & spectral power'],
    ['RMS Tremor Amplitude', `${session.rms.toFixed(4)} G-Force`, 'Root Mean Square kinematic acceleration vector'],
    ['Dominant Tremor Frequency', `${session.frequency.toFixed(2)} Hz`, freqBand]
  ];

  autoTable(doc, {
    startY: currentY,
    head: [['Biomarker Parameter', 'Measured Value', 'Diagnostic Reference / Interpretation']],
    body: findingsData,
    theme: 'grid',
    headStyles: { fillColor: [37, 99, 235], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 9 }, // Blue 600
    bodyStyles: { fontSize: 8.5, textColor: [30, 41, 59] },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 55 },
      1: { cellWidth: 40, fontStyle: 'bold' },
      2: { cellWidth: 85 }
    }
  });

  currentY = ((doc as any).lastAutoTable?.finalY ?? currentY + 30) + 6;

  // Section 4: Clinical Interpretation & Assessment Notes
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text('4. Quantitative Assessment Impression & Physician Review', 14, currentY);
  doc.setLineWidth(0.5);
  doc.line(14, currentY + 2, 196, currentY + 2);
  currentY += 6;

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(51, 65, 85);

  let interpretation = '';
  if (session.stage === 'Stage 3') {
    interpretation = 'Severe tremor oscillations detected across multi-axis kinematics. High-amplitude rhythmic excursions with profound motor disruption. Immediate formal neurologist review and medication response evaluation recommended.';
  } else if (session.stage === 'Stage 2') {
    interpretation = 'Moderate tremor activity identified. Prominent rhythmic oscillations observed during assessment. Consistent monitoring and functional motor therapy indicated.';
  } else if (session.stage === 'Stage 1') {
    interpretation = 'Mild or emergent tremor detected. Low-amplitude oscillations with early-stage kinematic markers. Longitudinal follow-up advised.';
  } else {
    interpretation = 'No pathological tremor characteristics detected. Sensor readings remain within baseline physiological variance.';
  }

  doc.text(interpretation, 14, currentY, { maxWidth: 182 });
  currentY += 14;

  if (patient?.notes) {
    doc.setFont('helvetica', 'bold');
    doc.text('Clinical Observations:', 14, currentY);
    doc.setFont('helvetica', 'italic');
    doc.text(patient.notes, 52, currentY, { maxWidth: 144 });
    currentY += 12;
  }

  // Physician Sign-off block
  currentY += 6;
  doc.setFont('helvetica', 'normal');
  doc.setDrawColor(148, 163, 184);
  doc.line(14, currentY + 12, 90, currentY + 12);
  doc.line(120, currentY + 12, 196, currentY + 12);

  doc.setFontSize(8);
  doc.setTextColor(100);
  doc.text(`Attending Physician / Examiner (${patient?.clinicianName || 'Signature'})`, 14, currentY + 16);
  doc.text(`Date & Verification (${dateStr.split(' ')[0]})`, 120, currentY + 16);

  // Footer on all pages
  const pageCount = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text(
      'CONFIDENTIAL CLINICAL ASSESSMENT — Generated via NeuroTremor for investigational screening & decision support. Not a diagnostic device.',
      doc.internal.pageSize.width / 2,
      doc.internal.pageSize.height - 8,
      { align: 'center' }
    );
  }

  doc.save(fileName);
};
