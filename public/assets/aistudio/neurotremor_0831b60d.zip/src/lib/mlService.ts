import * as tf from '@tensorflow/tfjs';
import { SensorData } from './serial';

export interface TremorFeatures {
  rms: number;
  frequency: number;
  avgForce: number;
  variance: number;
  amplitude: number;
}

export type SensitivityLevel = 'low' | 'normal' | 'high';

const WINDOW_SIZE = 40; // 2 seconds at 20Hz
const CHANNELS = 6; // ax, ay, az, gx, gy, gz

export class TremorMLService {
  private model: tf.LayersModel | null = null;
  private isModelLoaded = false;
  private isModelTrained = false;
  private isTraining = false;
  private sensitivity: SensitivityLevel = 'normal';
  private customMultiplier: number = 1.35; // Calibrated clinical baseline
  private smoothedSeverity: number = 0;

  setSensitivity(level: SensitivityLevel) {
    this.sensitivity = level;
    if (level === 'low') this.customMultiplier = 2.0; // Strongly dampened (rejects handwriting/voluntary strokes)
    else if (level === 'normal') this.customMultiplier = 1.35; // Optimized balanced clinical baseline
    else if (level === 'high') this.customMultiplier = 0.90; // Sensitive to subtle micro-oscillations
  }

  getSensitivity(): SensitivityLevel {
    return this.sensitivity;
  }

  setSensitivityMultiplier(mult: number) {
    this.customMultiplier = Math.max(0.5, Math.min(3.0, mult));
  }

  getSensitivityMultiplier(): number {
    return this.customMultiplier;
  }

  /**
   * Initialize the CNN model. Loads from IndexedDB if available,
   * otherwise builds a new model.
   */
  async initModel() {
    try {
      this.model = await tf.loadLayersModel('indexeddb://tremor-cnn-model-v2');
      this.isModelLoaded = true;
      this.isModelTrained = true;
      console.log('Loaded existing CNN model from IndexedDB');
      
      this.model.compile({
        optimizer: tf.train.adam(0.001),
        loss: 'sparseCategoricalCrossentropy',
        metrics: ['accuracy']
      });
      return true;
    } catch (error) {
      console.log('Creating new CNN model for continuous learning');
      this.model = this.buildCNN();
      this.isModelLoaded = true;
      this.isModelTrained = false;
      return true;
    }
  }

  private buildCNN(): tf.LayersModel {
    const model = tf.sequential();
    
    model.add(tf.layers.conv1d({
      filters: 16,
      kernelSize: 3,
      activation: 'relu',
      inputShape: [WINDOW_SIZE, CHANNELS]
    }));
    model.add(tf.layers.maxPooling1d({ poolSize: 2 }));
    
    model.add(tf.layers.conv1d({
      filters: 32,
      kernelSize: 3,
      activation: 'relu'
    }));
    model.add(tf.layers.maxPooling1d({ poolSize: 2 }));
    
    model.add(tf.layers.flatten());
    model.add(tf.layers.dense({ units: 64, activation: 'relu' }));
    model.add(tf.layers.dropout({ rate: 0.5 }));
    // 4 classes: Normal (0), Mild (1), Moderate (2), Severe (3)
    model.add(tf.layers.dense({ units: 4, activation: 'softmax' }));

    model.compile({
      optimizer: tf.train.adam(0.001),
      loss: 'sparseCategoricalCrossentropy',
      metrics: ['accuracy']
    });

    return model;
  }

  /**
   * Extract features from a window of sensor data.
   * Uses local trend subtraction to isolate rhythmic tremor from voluntary movements.
   */
  extractFeatures(dataWindow: SensorData[], deviceType: 'mobile' | 'pen' = 'mobile'): TremorFeatures {
    if (dataWindow.length < 10) {
      return { rms: 0, frequency: 0, avgForce: 0, variance: 0, amplitude: 0 };
    }

    // 1. Isolate tremor band (3.0 - 12.0 Hz) from gross voluntary movement (< 2.5 Hz):
    // Sliding local baseline average (~8 samples, approx ~200-300ms) estimates voluntary trajectory
    const baselineWindow = Math.min(8, Math.floor(dataWindow.length / 2));
    const dynamicMagnitudes: number[] = [];

    for (let i = 0; i < dataWindow.length; i++) {
      const start = Math.max(0, i - baselineWindow);
      const end = Math.min(dataWindow.length, i + baselineWindow + 1);
      const count = end - start;

      let bX = 0, bY = 0, bZ = 0;
      for (let j = start; j < end; j++) {
        bX += dataWindow[j].ax;
        bY += dataWindow[j].ay;
        bZ += dataWindow[j].az;
      }
      bX /= count;
      bY /= count;
      bZ /= count;

      const oscX = dataWindow[i].ax - bX;
      const oscY = dataWindow[i].ay - bY;
      const oscZ = dataWindow[i].az - bZ;

      dynamicMagnitudes.push(Math.sqrt(oscX * oscX + oscY * oscY + oscZ * oscZ));
    }

    // 2. Calculate RMS of oscillatory dynamic acceleration
    const sumSquared = dynamicMagnitudes.reduce((acc, val) => acc + (val * val), 0);
    const variance = sumSquared / dynamicMagnitudes.length;
    let rms = Math.sqrt(variance);

    // Apply noise-floor deadband:
    // Natural human physiological resting state and IMU thermal noise floor is ~0.45 m/s²
    const noiseDeadband = deviceType === 'pen' ? 0.45 : 0.55;
    if (rms < noiseDeadband) {
      rms = 0;
    }

    // 3. Dominant Frequency Analysis with hysteresis deadband
    const meanDynMag = dynamicMagnitudes.reduce((a, b) => a + b, 0) / dynamicMagnitudes.length;
    let zeroCrossings = 0;
    const hysteresis = deviceType === 'pen' ? 0.35 : 0.40;
    let isAbove = dynamicMagnitudes[0] > meanDynMag + hysteresis;

    for (let i = 1; i < dynamicMagnitudes.length; i++) {
      const mag = dynamicMagnitudes[i];
      if (isAbove && mag < meanDynMag - hysteresis) {
        zeroCrossings++;
        isAbove = false;
      } else if (!isAbove && mag > meanDynMag + hysteresis) {
        zeroCrossings++;
        isAbove = true;
      }
    }

    const durationSec = (dataWindow[dataWindow.length - 1].timestamp - dataWindow[0].timestamp) / 1000;
    let rawFrequency = durationSec > 0.1 ? (zeroCrossings / 2) / durationSec : 0;
    let frequency = rms === 0 ? 0 : rawFrequency;
    if (frequency > 16) frequency = 16;

    const avgForce = dataWindow.reduce((acc, d) => acc + d.fsr, 0) / dataWindow.length;
    const amplitude = Math.max(...dynamicMagnitudes);

    return { rms, frequency, avgForce, variance, amplitude };
  }

  private prepareTensor(dataWindow: SensorData[]): tf.Tensor3D | null {
    if (dataWindow.length < WINDOW_SIZE) return null;
    const slice = dataWindow.slice(-WINDOW_SIZE);
    const values = slice.map(d => [d.ax, d.ay, d.az, d.gx, d.gy, d.gz]);
    return tf.tensor3d([values], [1, WINDOW_SIZE, CHANNELS]);
  }

  /**
   * Run inference using the loaded CNN model or a fallback heuristic.
   * Returns a severity score (0 to 4).
   */
  async predictSeverity(dataWindow: SensorData[], features: TremorFeatures, deviceType: 'mobile' | 'pen' = 'mobile'): Promise<number> {
    if (this.isModelLoaded && this.isModelTrained && this.model) {
      const inputTensor = this.prepareTensor(dataWindow);
      if (inputTensor) {
        try {
          const prediction = this.model.predict(inputTensor) as tf.Tensor;
          const scoreData = await prediction.data();
          
          inputTensor.dispose();
          prediction.dispose();
          
          // Expected value calculation: 0*p0 + 1*p1 + 2*p2 + 3*p3
          let expectedValue = 0;
          for (let i = 0; i < 4; i++) {
            expectedValue += i * scoreData[i];
          }
          // Scale 0-3 to 0-4 range to match heuristic
          return expectedValue * (4/3);
        } catch (error) {
          console.error('Inference error, falling back to heuristic:', error);
          if (inputTensor) inputTensor.dispose();
          return this.heuristicPrediction(features, deviceType);
        }
      }
    }
    return this.heuristicPrediction(features, deviceType);
  }

  /**
   * Train the CNN model on a recorded session to enable continuous learning.
   */
  async trainOnSession(sessionData: SensorData[], severityLabel: string) {
    if (!this.model || sessionData.length < WINDOW_SIZE) return;
    if (this.isTraining) return;
    
    this.isTraining = true;
    console.log(`Training CNN on new session data. Label: ${severityLabel}`);

    let labelIdx = 0;
    if (severityLabel === 'Mild') labelIdx = 1;
    if (severityLabel === 'Moderate') labelIdx = 2;
    if (severityLabel === 'Severe') labelIdx = 3;

    try {
      const inputs: number[][][] = [];
      const labels: number[] = [];

      // Slide window by 10 samples (0.5s) to augment data
      const step = 10;
      for (let i = 0; i <= sessionData.length - WINDOW_SIZE; i += step) {
        const slice = sessionData.slice(i, i + WINDOW_SIZE);
        const values = slice.map(d => [d.ax, d.ay, d.az, d.gx, d.gy, d.gz]);
        inputs.push(values);
        labels.push(labelIdx);
      }

      if (inputs.length === 0) {
        this.isTraining = false;
        return;
      }

      const xs = tf.tensor3d(inputs, [inputs.length, WINDOW_SIZE, CHANNELS]);
      const ys = tf.tensor1d(labels, 'int32');

      await this.model.fit(xs, ys, {
        epochs: 5,
        batchSize: 8,
        shuffle: true
      });

      xs.dispose();
      ys.dispose();

      await this.model.save('indexeddb://tremor-cnn-model-v2');
      this.isModelTrained = true;
      console.log('Model trained and saved successfully!');
    } catch (error) {
      console.error('Error training model:', error);
    } finally {
      this.isTraining = false;
    }
  }

  /**
   * Calibrated heuristic prediction mapping features to 0-4 UPDRS severity scale.
   * Incorporates voluntary movement rejection and temporal smoothing.
   */
  public heuristicPrediction(features: TremorFeatures, deviceType: 'mobile' | 'pen' = 'mobile'): number {
    const rms = features.rms;
    const freq = features.frequency;
    const mult = this.customMultiplier;

    // If RMS is at zero deadband or frequency is slow voluntary movement (< 2.5 Hz), decay to normal
    if (rms === 0 || (freq > 0 && freq < 2.5)) {
      this.smoothedSeverity = this.smoothedSeverity * 0.7;
      return this.smoothedSeverity < 0.2 ? 0 : Math.round(this.smoothedSeverity);
    }

    let instantSeverity = 0;
    if (deviceType === 'mobile') {
      if (rms <= 4.5 * mult) {
        instantSeverity = 0; // Normal / Steady hold
      } else if (rms <= 9.0 * mult) {
        instantSeverity = 1; // Mild tremor
      } else if (rms <= 16.0 * mult) {
        instantSeverity = 2; // Moderate tremor
      } else if (rms <= 24.0 * mult) {
        instantSeverity = 3; // Severe tremor
      } else {
        instantSeverity = 4; // Very severe tremor
      }
    } else {
      // Pen held in fingers (fine motor kinematics):
      if (rms <= 3.8 * mult) {
        instantSeverity = 0; // Normal physiological stability
      } else if (rms <= 8.5 * mult) {
        instantSeverity = 1; // Mild tremor
      } else if (rms <= 15.0 * mult) {
        instantSeverity = 2; // Moderate tremor
      } else if (rms <= 22.0 * mult) {
        instantSeverity = 3; // Severe tremor
      } else {
        instantSeverity = 4; // Very severe tremor
      }
    }

    // Voluntary motion rejection:
    // If motion frequency is < 3.0 Hz and amplitude is not violent, it is handwriting or intentional movement
    if (freq < 3.0 && instantSeverity <= 2) {
      instantSeverity = 0;
    }

    // Exponential moving average smoothing avoids false triggers from sudden single jerks
    this.smoothedSeverity = (0.35 * instantSeverity) + (0.65 * this.smoothedSeverity);
    const finalSeverity = Math.round(this.smoothedSeverity);

    return Math.max(0, Math.min(4, finalSeverity));
  }

  /**
   * Maps severity score to disease stage (Stage 1, 2, 3)
   */
  public getStage(severity: number): string {
    if (severity === 0) return 'Normal';
    if (severity <= 1.5) return 'Stage 1';
    if (severity <= 2.5) return 'Stage 2';
    if (severity <= 3.5) return 'Stage 3';
    return 'Stage 4';
  }
}

export const mlService = new TremorMLService();
