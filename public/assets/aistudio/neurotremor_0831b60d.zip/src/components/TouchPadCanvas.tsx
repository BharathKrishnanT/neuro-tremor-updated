import React, { useRef, useEffect, useState } from 'react';
import { SensorData } from '../lib/serial';
import { Maximize2, Minimize2 } from 'lucide-react';
import { useLanguage } from '../lib/i18n';

export function TouchPadCanvas({ onData, mode = 'touch', onTouchUpdate }: { onData: (data: SensorData) => void, mode?: 'touch' | 'combined', onTouchUpdate?: (x: number, y: number, pressure: number) => void }) {
  const { t } = useLanguage();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasDrawn, setHasDrawn] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  
  const lastPos = useRef<{x: number, y: number, t: number} | null>(null);
  const lastVel = useRef<{vx: number, vy: number, ax: number, ay: number} | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const drawGrid = (ctx: CanvasRenderingContext2D, w: number, h: number) => {
      ctx.clearRect(0, 0, w, h);
      ctx.strokeStyle = '#333';
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let i = 0; i < 500; i++) {
        const angle = 0.1 * i;
        const x = w / 2 + (1 + angle) * Math.cos(angle) * (w > 1000 ? 8 : 5);
        const y = h / 2 + (1 + angle) * Math.sin(angle) * (w > 1000 ? 8 : 5);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      ctx.fillStyle = '#666';
      ctx.font = '14px Inter, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(t('canvasWatermark'), w / 2, 30);
    };

    const handleResize = () => {
      const parent = canvas.parentElement;
      if (!parent) return;
      const rect = parent.getBoundingClientRect();
      
      // Only resize if substantially different to avoid jitter
      if (Math.abs(canvas.width - rect.width) > 5 || Math.abs(canvas.height - rect.height) > 5) {
        canvas.width = rect.width;
        canvas.height = rect.height;
        
        const ctx = canvas.getContext('2d');
        if (ctx) drawGrid(ctx, canvas.width, canvas.height);
      }
    };

    const observer = new ResizeObserver(() => {
      handleResize();
    });

    if (canvas.parentElement) {
      observer.observe(canvas.parentElement);
    }
    
    // Initial draw
    handleResize();

    return () => observer.disconnect();
  }, [isFullscreen]);

  const getCanvasCoordinates = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    return {
      x: e.nativeEvent.offsetX * scaleX,
      y: e.nativeEvent.offsetY * scaleY
    };
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    setIsDrawing(true);
    setHasDrawn(true);
    lastPos.current = { x: e.clientX, y: e.clientY, t: Date.now() };
    lastVel.current = { vx: 0, vy: 0, ax: 0, ay: 0 };
    
    // Setup drawing
    const ctx = canvasRef.current?.getContext('2d');
    if (ctx) {
      const { x, y } = getCanvasCoordinates(e);
      ctx.beginPath();
      ctx.moveTo(x, y);
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !lastPos.current || !lastVel.current) return;
    
    const now = Date.now();
    const dt = (now - lastPos.current.t) / 1000; // seconds
    if (dt === 0) return;

    const dx = e.clientX - lastPos.current.x;
    const dy = e.clientY - lastPos.current.y;
    
    // Sub-pixel deadband to ignore jitter
    const dist = Math.sqrt(dx * dx + dy * dy);
    if (dist < 1.5) {
      lastPos.current = { x: e.clientX, y: e.clientY, t: now };
      return;
    }

    // Pixel to meter conversion (calibrated for standard display PPI)
    const pxToMeter = 0.00015; 
    
    const vx = (dx * pxToMeter) / dt;
    const vy = (dy * pxToMeter) / dt;
    
    // Calculate raw acceleration and clamp to realistic human motor range (+/- 6 m/s²)
    const rawAx = Math.max(-6, Math.min(6, (vx - lastVel.current.vx) / dt));
    const rawAy = Math.max(-6, Math.min(6, (vy - lastVel.current.vy) / dt));
    
    // Heavy low-pass filter (0.85 old + 0.15 new) to eliminate digital derivative noise
    const ax = lastVel.current.vx === 0 ? rawAx * 0.2 : (lastVel.current.ax || 0) * 0.85 + rawAx * 0.15;
    const ay = lastVel.current.vy === 0 ? rawAy * 0.2 : (lastVel.current.ay || 0) * 0.85 + rawAy * 0.15;

    // Send the simulated sensor data
    const pressure = e.pressure !== undefined ? e.pressure * 4095 : 2048;
    
    const { x, y } = getCanvasCoordinates(e);

    if (mode === 'touch') {
      onData({
        timestamp: now,
        ax: ax,
        ay: ay,
        az: 9.8, // Gravity
        gx: 0,
        gy: 0,
        gz: 0,
        mx: 0,
        my: 0,
        mz: 0,
        fsr: pressure,
        touchX: x,
        touchY: y
      });
    } else if (onTouchUpdate) {
      onTouchUpdate(x, y, pressure);
    }

    // Update drawing
    const ctx = canvasRef.current?.getContext('2d');
    if (ctx) {
      ctx.lineTo(x, y);
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 2;
      ctx.stroke();
    }

    lastPos.current = { x: e.clientX, y: e.clientY, t: now };
    lastVel.current = { vx, vy, ax, ay };
  };

  const handlePointerUp = () => {
    setIsDrawing(false);
    lastPos.current = null;
    lastVel.current = null;
  };

  return (
    <div className={
      isFullscreen
        ? "fixed inset-0 z-50 bg-slate-950 p-6 flex flex-col"
        : "bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-lg p-4 mb-6 flex flex-col shadow-2xs"
    }>
      <div className="mb-3 flex justify-between items-start flex-shrink-0">
        <div>
          <h2 className="text-sm font-semibold uppercase tracking-wider text-slate-900 dark:text-slate-100">{t('touchPadTitle')}</h2>
          <p className="text-slate-500 dark:text-slate-400 text-xs mt-0.5">{t('touchPadSubtitle')}</p>
        </div>
        <button
          onClick={() => setIsFullscreen(!isFullscreen)}
          className="p-1.5 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 rounded-md transition-colors flex-shrink-0 ml-4 border border-slate-200 dark:border-slate-700"
          title={isFullscreen ? t('exitFullscreen') : t('enterFullscreen')}
        >
          {isFullscreen ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
        </button>
      </div>
      <div className={`w-full ${isFullscreen ? 'flex-1' : 'h-80'} bg-slate-950 rounded-lg overflow-hidden border border-slate-800 cursor-crosshair min-h-0 relative`}>
        {!hasDrawn && (
          <div className="absolute inset-x-0 bottom-3 flex justify-center pointer-events-none z-10">
            <div className="bg-slate-900/90 border border-slate-700 text-slate-200 text-xs px-3 py-1 rounded shadow-md flex items-center space-x-2 font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-sky-400" />
              <span>{t('traceSpiralHint')}</span>
            </div>
          </div>
        )}
        <canvas
          ref={canvasRef}
          width={800}
          height={320}
          className="w-full h-full touch-none block"
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerLeave={handlePointerUp}
          onPointerCancel={handlePointerUp}
        />
      </div>
      <div className="mt-3 flex justify-end flex-shrink-0">
        <button 
          onClick={() => {
            setHasDrawn(false);
            const canvas = canvasRef.current;
            const ctx = canvas?.getContext('2d');
            if (ctx && canvas) {
              const w = canvas.width;
              const h = canvas.height;
              ctx.clearRect(0, 0, w, h);
              
              // Redraw spiral
              ctx.strokeStyle = '#334155';
              ctx.lineWidth = 1;
              ctx.beginPath();
              for (let i = 0; i < 500; i++) {
                const angle = 0.1 * i;
                const x = w / 2 + (1 + angle) * Math.cos(angle) * (w > 1000 ? 8 : 5);
                const y = h / 2 + (1 + angle) * Math.sin(angle) * (w > 1000 ? 8 : 5);
                if (i === 0) ctx.moveTo(x, y);
                else ctx.lineTo(x, y);
              }
              ctx.stroke();
              
              ctx.fillStyle = '#64748b';
              ctx.font = '12px "IBM Plex Mono", monospace';
              ctx.textAlign = 'center';
              ctx.fillText(t('canvasWatermark'), w / 2, 28);
            }
          }}
          className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 transition-colors rounded-md text-xs font-medium"
        >
          {t('clearCanvas')}
        </button>
      </div>
    </div>
  );
}
