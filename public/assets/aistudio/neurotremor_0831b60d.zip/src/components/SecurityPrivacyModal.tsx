import React, { useState } from 'react';
import { Shield, Lock, FileText, AlertTriangle, CheckCircle2, Trash2, X, Database, EyeOff, Cookie, Cpu } from 'lucide-react';
import { useLanguage } from '../lib/i18n';

interface SecurityPrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultTab?: 'medical' | 'privacy' | 'cookies' | 'security';
  isDark?: boolean;
}

export const SecurityPrivacyModal: React.FC<SecurityPrivacyModalProps> = ({
  isOpen,
  onClose,
  defaultTab = 'medical',
  isDark = true
}) => {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'medical' | 'privacy' | 'cookies' | 'security'>(defaultTab);
  const [cacheCleared, setCacheCleared] = useState(false);

  if (!isOpen) return null;

  const handleClearLocalStorage = () => {
    try {
      localStorage.removeItem('neurotremor_calibration_offsets');
      localStorage.removeItem('neuro_theme');
      localStorage.removeItem('neurotremor_lang');
      localStorage.removeItem('neurotremor_privacy_accepted');
      setCacheCleared(true);
      setTimeout(() => setCacheCleared(false), 3000);
    } catch (e) {
      console.error("Failed to clear local storage", e);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        role="dialog"
        aria-modal="true"
        aria-labelledby="security-modal-title"
        className="relative w-full max-w-3xl max-h-[90vh] flex flex-col rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden transition-all"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/40">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-md bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-400 border border-sky-200 dark:border-sky-800">
              <Shield size={18} />
            </div>
            <div>
              <h2 id="security-modal-title" className="text-sm font-semibold uppercase tracking-wider text-slate-900 dark:text-slate-100">
                {t('securityPrivacyTitle') || "Security, Privacy & Clinical Disclaimer"}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                NeuroTremor Quantitative Motor Assessment Architecture
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close modal"
            className="p-1 rounded-md text-slate-400 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 px-5 bg-slate-50/40 dark:bg-slate-950/20 overflow-x-auto">
          <button
            onClick={() => setActiveTab('medical')}
            className={`py-2.5 px-3 text-xs font-medium border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'medical'
                ? 'border-amber-600 text-amber-700 dark:text-amber-400'
                : 'border-transparent text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            <AlertTriangle size={13} />
            <span>{t('medicalDisclaimerTab') || "Medical Disclaimer"}</span>
          </button>

          <button
            onClick={() => setActiveTab('privacy')}
            className={`py-2.5 px-3 text-xs font-medium border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'privacy'
                ? 'border-sky-700 text-sky-700 dark:text-sky-400'
                : 'border-transparent text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            <Lock size={13} />
            <span>{t('dataPrivacyTab') || "Data Privacy Policy"}</span>
          </button>

          <button
            onClick={() => setActiveTab('cookies')}
            className={`py-2.5 px-3 text-xs font-medium border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'cookies'
                ? 'border-emerald-600 text-emerald-700 dark:text-emerald-400'
                : 'border-transparent text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            <Cookie size={13} />
            <span>{t('cookieStorageTab') || "Cookies & Storage"}</span>
          </button>

          <button
            onClick={() => setActiveTab('security')}
            className={`py-2.5 px-3 text-xs font-medium border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'security'
                ? 'border-slate-800 text-slate-900 dark:border-slate-300 dark:text-slate-100'
                : 'border-transparent text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            <Cpu size={13} />
            <span>{t('systemSecurityTab') || "System Security"}</span>
          </button>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-6 text-sm text-slate-700 dark:text-zinc-300 space-y-4">
          {activeTab === 'medical' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 text-amber-900 dark:text-amber-200 text-xs sm:text-sm leading-relaxed">
                <div className="flex items-center gap-2 font-bold mb-1.5 text-amber-800 dark:text-amber-300">
                  <AlertTriangle size={16} />
                  <span>Important Medical Notice & Non-Diagnostic Status</span>
                </div>
                NeuroTremor is an investigational, decision-support research and screening utility designed for quantitative motor tremor recording (IMU acceleration, angular velocity, and FSR pen force). It is <strong>NOT an FDA, CE, or CDSCO cleared diagnostic medical device</strong> and does NOT generate definitive clinical diagnoses.
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-bold text-slate-900 dark:text-zinc-100">1. Purpose and Clinical Context</h3>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-zinc-400 leading-relaxed">
                  The metrics provided (e.g., RMS acceleration, dominant frequency in Hz, and stage estimations) represent biometric motion characteristics. These readings assist clinicians and researchers with objective movement tracking, but must always be interpreted in conjunction with comprehensive clinical history, neurological physical examination (UPDRS), and medical imaging.
                </p>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-bold text-slate-900 dark:text-zinc-100">2. No Patient-Physician Relationship</h3>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-zinc-400 leading-relaxed">
                  Use of this web application does not establish a doctor-patient relationship. Do not alter prescribed medication regimens, dosages, or physical therapy programs based on software outputs without direct supervision from a qualified neurologist.
                </p>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-bold text-slate-900 dark:text-zinc-100">3. Emergency Care</h3>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-zinc-400 leading-relaxed">
                  If you or someone under your care experiences sudden paralysis, loss of speech, severe confusion, sudden violent tremors, or acute medical distress, call emergency services (e.g., 911, 112) immediately.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'privacy' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/60 text-blue-900 dark:text-blue-200 text-xs sm:text-sm leading-relaxed">
                <div className="flex items-center gap-2 font-bold mb-1 text-blue-800 dark:text-blue-300">
                  <Lock size={16} />
                  <span>Privacy by Design & Data Minimization</span>
                </div>
                NeuroTremor operates on a strict zero-tracker policy. Your telemetry, motion captures, and clinical PDF exports belong exclusively to you.
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3.5 rounded-xl border border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-950/50">
                  <div className="flex items-center gap-2 font-semibold text-xs text-slate-900 dark:text-zinc-200 mb-1">
                    <Cpu size={14} className="text-blue-500" />
                    Local-First Edge ML
                  </div>
                  <p className="text-xs text-slate-500 dark:text-zinc-400">
                    Real-time tremor feature extraction and CNN inference run entirely within your local browser sandbox via TensorFlow.js. Live sensor streams are never streamed to remote ad servers.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl border border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-950/50">
                  <div className="flex items-center gap-2 font-semibold text-xs text-slate-900 dark:text-zinc-200 mb-1">
                    <Database size={14} className="text-emerald-500" />
                    Secure Cloud Storage
                  </div>
                  <p className="text-xs text-slate-500 dark:text-zinc-400">
                    When signed in, sessions are saved to Google Firebase Firestore under strict per-user security rules (`isDocOwner`). No other user or third party can access your telemetry.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl border border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-950/50">
                  <div className="flex items-center gap-2 font-semibold text-xs text-slate-900 dark:text-zinc-200 mb-1">
                    <EyeOff size={14} className="text-purple-500" />
                    Zero Commercial Trackers
                  </div>
                  <p className="text-xs text-slate-500 dark:text-zinc-400">
                    No Google Analytics, Meta Pixels, or advertising beacons are embedded. We do not sell, monetize, or harvest user telemetry.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl border border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-950/50">
                  <div className="flex items-center gap-2 font-semibold text-xs text-slate-900 dark:text-zinc-200 mb-1">
                    <Shield size={14} className="text-rose-500" />
                    Zero Payment Processing
                  </div>
                  <p className="text-xs text-slate-500 dark:text-zinc-400">
                    NeuroTremor does not process credit cards, subscriptions, or financial transactions. No financial data is ever collected or stored.
                  </p>
                </div>
              </div>

              <div className="space-y-1.5 pt-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-zinc-300">Right to Erasure (Data Deletion)</h4>
                <p className="text-xs text-slate-600 dark:text-zinc-400">
                  You can permanently delete any recorded session at any time directly from the Historical Sessions list. Deletion is instantaneous and permanent across Firestore database shards.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'cookies' && (
            <div className="space-y-4">
              <p className="text-xs sm:text-sm text-slate-600 dark:text-zinc-400 leading-relaxed">
                NeuroTremor does not use invasive advertising or tracking cookies. Only functional browser storage is utilized to remember your selected preferences across sessions:
              </p>

              <div className="border border-slate-200 dark:border-zinc-800 rounded-xl overflow-hidden text-xs">
                <table className="w-full text-left">
                  <thead className="bg-slate-100 dark:bg-zinc-800/80 text-slate-700 dark:text-zinc-300 border-b border-slate-200 dark:border-zinc-700 font-semibold">
                    <tr>
                      <th className="p-2.5">Storage Key</th>
                      <th className="p-2.5">Type</th>
                      <th className="p-2.5">Purpose</th>
                      <th className="p-2.5">Duration</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-zinc-800/60 font-mono text-[11px] text-slate-600 dark:text-zinc-400">
                    <tr>
                      <td className="p-2.5 font-bold text-slate-800 dark:text-zinc-200">neurotremor_lang</td>
                      <td className="p-2.5">localStorage</td>
                      <td className="p-2.5 font-sans">Remembers chosen UI language (e.g. English, Tamil, Spanish)</td>
                      <td className="p-2.5 font-sans">Persistent</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 font-bold text-slate-800 dark:text-zinc-200">neuro_theme</td>
                      <td className="p-2.5">localStorage</td>
                      <td className="p-2.5 font-sans">Remembers Dark/Light interface contrast mode</td>
                      <td className="p-2.5 font-sans">Persistent</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 font-bold text-slate-800 dark:text-zinc-200">neurotremor_calibration_offsets</td>
                      <td className="p-2.5">localStorage</td>
                      <td className="p-2.5 font-sans">Hardware zero tare values (accel, gyro, mag, pressure)</td>
                      <td className="p-2.5 font-sans">Persistent</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 font-bold text-slate-800 dark:text-zinc-200">neurotremor_privacy_accepted</td>
                      <td className="p-2.5">localStorage</td>
                      <td className="p-2.5 font-sans">Acknowledges privacy & non-diagnostic notice</td>
                      <td className="p-2.5 font-sans">Persistent</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="pt-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-slate-50 dark:bg-zinc-950/40 border border-slate-200 dark:border-zinc-800">
                <div>
                  <div className="text-xs font-semibold text-slate-900 dark:text-zinc-200">Reset Local Client Cache</div>
                  <div className="text-[11px] text-slate-500 dark:text-zinc-400">Wipes all stored hardware calibration offsets and theme preferences from this browser.</div>
                </div>
                <button
                  onClick={handleClearLocalStorage}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:text-rose-400 dark:hover:bg-rose-900/40 border border-rose-200 dark:border-rose-800/40 transition-colors whitespace-nowrap"
                >
                  <Trash2 size={13} />
                  <span>{cacheCleared ? "Cleared!" : "Clear Local Storage"}</span>
                </button>
              </div>
            </div>
          )}

          {activeTab === 'security' && (
            <div className="space-y-4">
              <div className="space-y-2">
                <h3 className="text-sm font-bold text-slate-900 dark:text-zinc-100 flex items-center gap-2">
                  <Shield size={16} className="text-purple-500" />
                  Hardened Production Architecture
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-zinc-400 leading-relaxed">
                  NeuroTremor is deployed with bank-grade transport and application security headers to protect against Cross-Site Scripting (XSS), Clickjacking, MIME sniffing, and unauthorized hardware access:
                </p>
              </div>

              <div className="space-y-2 text-xs">
                <div className="p-3 rounded-lg border border-slate-200 dark:border-zinc-800 bg-slate-50/70 dark:bg-zinc-950/40 flex items-start gap-2.5">
                  <CheckCircle2 size={15} className="text-emerald-500 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-800 dark:text-zinc-200 font-mono">Content-Security-Policy (CSP):</strong> Restricts script execution strictly to verified application bundles, disables unsafe-eval, and disallows untrusted third-party frame embedding.
                  </div>
                </div>

                <div className="p-3 rounded-lg border border-slate-200 dark:border-zinc-800 bg-slate-50/70 dark:bg-zinc-950/40 flex items-start gap-2.5">
                  <CheckCircle2 size={15} className="text-emerald-500 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-800 dark:text-zinc-200 font-mono">HSTS & TLS Enforcement:</strong> Strict-Transport-Security (2-year preload max-age) guarantees all communication occurs over encrypted HTTPS connections.
                  </div>
                </div>

                <div className="p-3 rounded-lg border border-slate-200 dark:border-zinc-800 bg-slate-50/70 dark:bg-zinc-950/40 flex items-start gap-2.5">
                  <CheckCircle2 size={15} className="text-emerald-500 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-800 dark:text-zinc-200 font-mono">Least-Privilege Permissions-Policy:</strong> Hardware APIs (Serial, Bluetooth, Accelerometer) are locked exclusively to the origin (`self`). Camera, microphone, and payment gateways (`payment=()`) are permanently disabled.
                  </div>
                </div>

                <div className="p-3 rounded-lg border border-slate-200 dark:border-zinc-800 bg-slate-50/70 dark:bg-zinc-950/40 flex items-start gap-2.5">
                  <CheckCircle2 size={15} className="text-emerald-500 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-slate-800 dark:text-zinc-200 font-mono">Server-Side Firestore Rules:</strong> All database operations enforce cryptographically validated authentication (`request.auth.uid == resource.data.userId`), preventing unauthorized access or spoofed user IDs.
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-5 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/40">
          <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1.5 font-mono">
            <Lock size={12} className="text-emerald-600 dark:text-emerald-400" />
            <span>ENCRYPTED LOCAL RUNTIME</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-md bg-slate-800 hover:bg-slate-900 text-white dark:bg-slate-700 dark:hover:bg-slate-600 dark:text-slate-100 font-medium text-xs transition-colors shadow-2xs"
          >
            {t('close') || "Understood & Close"}
          </button>
        </div>
      </div>
    </div>
  );
};
