import React from 'react';
import { Activity, Gauge, AlertCircle, TrendingUp } from 'lucide-react';
import { useLanguage } from '../lib/i18n';

interface TremorAnalysisProps {
  metrics: {
    rms: number;
    frequency: number;
    intensity: string;
    stage: string;
    recoveryRate?: number;
  };
}

export const TremorAnalysis: React.FC<TremorAnalysisProps> = ({ metrics }) => {
  const { t } = useLanguage();

  const getTranslatedStage = (stage: string) => {
    if (stage === 'Normal' || stage === 'Stage 0') return t('normal');
    if (stage === 'Mild' || stage === 'Stage 1') return t('mild');
    if (stage === 'Moderate' || stage === 'Stage 2') return t('moderate');
    if (stage === 'Severe' || stage === 'Stage 3') return t('severe');
    return stage;
  };

  const isSevere = metrics.stage === 'Stage 3' || metrics.stage === 'Severe';
  const isModerate = metrics.stage === 'Stage 2' || metrics.stage === 'Moderate';
  const isMild = metrics.stage === 'Stage 1' || metrics.stage === 'Mild';
  const isNormal = !isSevere && !isModerate && !isMild;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 mb-6">
      {/* 1. RMS Acceleration Magnitude */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-lg p-3.5 shadow-2xs transition-colors">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
            {t('rmsAmplitude')}
          </span>
          <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500 bg-slate-100 dark:bg-slate-800/80 px-1.5 py-0.5 rounded">
            CALIBRATED RMS
          </span>
        </div>
        <div className="flex items-baseline space-x-2">
          <span className="text-2xl lg:text-3xl font-mono font-bold tracking-tight text-slate-900 dark:text-slate-100">
            {(metrics.rms / 9.80665).toFixed(3)}
          </span>
          <span className="text-xs font-mono text-slate-500 dark:text-slate-400">g</span>
          <span className="text-[11px] font-mono text-slate-400 dark:text-slate-500 ml-1">
            ({metrics.rms.toFixed(2)} m/s²)
          </span>
        </div>
        <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-800/70 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
          <span>Kinematic displacement</span>
          <span className="font-mono text-slate-600 dark:text-slate-300">
            {metrics.rms < 2.5 ? '<0.25g normal' : metrics.rms < 6.5 ? 'mild (0.25-0.65g)' : 'marked (>0.65g)'}
          </span>
        </div>
      </div>

      {/* 2. Dominant Tremor Frequency */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-lg p-3.5 shadow-2xs transition-colors">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
            {t('frequency')}
          </span>
          <span className="text-[10px] font-mono text-sky-700 dark:text-sky-400 bg-sky-50 dark:bg-sky-950/60 border border-sky-200/60 dark:border-sky-900 px-1.5 py-0.5 rounded">
            FFT PEAK
          </span>
        </div>
        <div className="flex items-baseline space-x-2">
          <span className="text-2xl lg:text-3xl font-mono font-bold tracking-tight text-slate-900 dark:text-slate-100">
            {metrics.frequency.toFixed(1)}
          </span>
          <span className="text-xs font-mono text-slate-500 dark:text-slate-400">Hz</span>
        </div>
        <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-800/70 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
          <span>Spectral band</span>
          <span className="font-mono text-slate-600 dark:text-slate-300">
            {metrics.frequency >= 4 && metrics.frequency <= 6
              ? '4-6 Hz resting'
              : metrics.frequency > 6 && metrics.frequency <= 12
              ? '6-12 Hz postural'
              : 'baseline'}
          </span>
        </div>
      </div>

      {/* 3. Clinical Stage Classification */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-lg p-3.5 shadow-2xs transition-colors">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
            {t('diseaseLevel')}
          </span>
          <span
            className={`text-[10px] font-medium px-2 py-0.5 rounded border ${
              isSevere
                ? 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/50 dark:text-rose-400 dark:border-rose-900'
                : isModerate
                ? 'bg-amber-50 text-amber-800 border-amber-200 dark:bg-amber-950/50 dark:text-amber-400 dark:border-amber-900'
                : isMild
                ? 'bg-sky-50 text-sky-800 border-sky-200 dark:bg-sky-950/50 dark:text-sky-400 dark:border-sky-900'
                : 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700'
            }`}
          >
            {metrics.stage || 'Stage 0'}
          </span>
        </div>
        <div className="flex items-baseline space-x-2">
          <span
            className={`text-2xl lg:text-3xl font-mono font-bold tracking-tight ${
              isSevere
                ? 'text-rose-700 dark:text-rose-400'
                : isModerate
                ? 'text-amber-700 dark:text-amber-400'
                : isMild
                ? 'text-sky-700 dark:text-sky-400'
                : 'text-slate-800 dark:text-slate-200'
            }`}
          >
            {getTranslatedStage(metrics.stage)}
          </span>
        </div>
        <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-800/70 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
          <span>Screening scale</span>
          <span className="font-mono text-slate-600 dark:text-slate-300">MDS-UPDRS III</span>
        </div>
      </div>

      {/* 4. Longitudinal Change / Trend */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-lg p-3.5 shadow-2xs transition-colors">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
            {t('recoveryRate')}
          </span>
          <span className="text-[10px] font-mono text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200/60 dark:border-emerald-900 px-1.5 py-0.5 rounded">
            DELTA
          </span>
        </div>
        <div className="flex items-baseline space-x-2">
          <span
            className={`text-2xl lg:text-3xl font-mono font-bold tracking-tight ${
              metrics.recoveryRate !== undefined && metrics.recoveryRate > 0
                ? 'text-emerald-700 dark:text-emerald-400'
                : metrics.recoveryRate !== undefined && metrics.recoveryRate < 0
                ? 'text-amber-700 dark:text-amber-400'
                : 'text-slate-900 dark:text-slate-100'
            }`}
          >
            {metrics.recoveryRate !== undefined
              ? `${metrics.recoveryRate > 0 ? '+' : ''}${metrics.recoveryRate.toFixed(1)}%`
              : '--'}
          </span>
        </div>
        <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-800/70 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
          <span>Session baseline</span>
          <span className="font-mono text-slate-600 dark:text-slate-300">
            {metrics.recoveryRate !== undefined ? 'Multi-session' : 'Pending logs'}
          </span>
        </div>
      </div>
    </div>
  );
};

