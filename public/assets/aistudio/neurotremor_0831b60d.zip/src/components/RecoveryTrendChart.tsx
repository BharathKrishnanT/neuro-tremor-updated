import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { Session } from '../App';
import { useLanguage } from '../lib/i18n';

interface RecoveryTrendChartProps {
  sessions: Session[];
  isDark?: boolean;
}

export const RecoveryTrendChart: React.FC<RecoveryTrendChartProps> = ({ sessions, isDark = false }) => {
  const { t } = useLanguage();

  // We want to show the trend from oldest to newest
  const chartData = [...sessions].reverse().map((session, index) => ({
    name: `${t('session').slice(0, 1).toUpperCase()}-${index + 1}`,
    rms: session.rms,
    frequency: session.frequency,
    timestamp: new Date(session.timestamp).toLocaleDateString(),
    fullDate: new Date(session.timestamp).toLocaleString()
  }));

  if (sessions.length < 2) {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-lg p-5 h-48 flex flex-col items-center justify-center text-center shadow-2xs">
        <p className="text-slate-700 dark:text-slate-300 text-xs font-semibold mb-1 uppercase tracking-wider">{t('notEnoughData')}</p>
        <p className="text-slate-500 dark:text-slate-400 text-xs">{t('recordAtLeastTwo')}</p>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-lg p-4 shadow-2xs">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-900 dark:text-slate-100">{t('recoveryProgress')}</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{t('recoverySubtitle')}</p>
        </div>
        <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700">
          N={sessions.length} SESSIONS
        </span>
      </div>

      <div className="h-56">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id="colorRms" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#0284c7" stopOpacity={0.18}/>
                <stop offset="95%" stopColor="#0284c7" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="2 2" stroke={isDark ? "#1e293b" : "#e2e8f0"} vertical={false} />
            <XAxis 
              dataKey="name" 
              stroke={isDark ? "#64748b" : "#94a3b8"} 
              fontSize={10} 
              tickLine={false} 
              axisLine={false}
              dy={6}
            />
            <YAxis 
              stroke={isDark ? "#64748b" : "#94a3b8"} 
              fontSize={10} 
              tickLine={false} 
              axisLine={false}
              tickFormatter={(val) => val.toFixed(2)}
              width={34}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: isDark ? '#0f172a' : '#ffffff', 
                border: isDark ? '1px solid #1e293b' : '1px solid #e2e8f0', 
                borderRadius: '6px',
                color: isDark ? '#f8fafc' : '#0f172a',
                fontSize: '11px',
                fontFamily: 'var(--font-mono)',
                boxShadow: '0 2px 8px rgba(0,0,0,0.06)'
              }}
              itemStyle={{ color: isDark ? '#f8fafc' : '#0f172a' }}
              labelStyle={{ color: isDark ? '#94a3b8' : '#64748b', marginBottom: '2px', fontSize: '10px' }}
              labelFormatter={(label, payload) => {
                if (payload && payload[0]) {
                  return payload[0].payload.fullDate;
                }
                return label;
              }}
            />
            <Area 
              type="monotone" 
              dataKey="rms" 
              stroke="#0284c7" 
              strokeWidth={2}
              fillOpacity={1} 
              fill="url(#colorRms)" 
              name={t('rmsAmplitude')}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
