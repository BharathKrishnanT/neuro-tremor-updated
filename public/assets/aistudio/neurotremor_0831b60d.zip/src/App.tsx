import React, { useState, useEffect, useRef, useCallback } from 'react';
import { serialService, SensorData } from './lib/serial';
import { bleService } from './lib/ble';
import { wifiService } from './lib/wifi';
import { mobileSensorService } from './lib/mobileSensors';
import { mlService, SensitivityLevel } from './lib/mlService';
import { audioFeedback } from './lib/audio';
import { exportService } from './lib/exportService';
import { LiveChart } from './components/LiveChart';
import { TremorAnalysis } from './components/TremorAnalysis';
import { DatasetUploader } from './components/DatasetUploader';
import { DatasetSummary } from './components/DatasetSummary';
import { RecoveryTrendChart } from './components/RecoveryTrendChart';
import { TouchPadCanvas } from './components/TouchPadCanvas';
import { LanguageSelector } from './components/LanguageSelector';
import { CalibrationModal, CalibrationOffsets, DEFAULT_OFFSETS } from './components/CalibrationModal';
import { PatientDetailsModal } from './components/PatientDetailsModal';
import { SecurityPrivacyModal } from './components/SecurityPrivacyModal';
import { ConsentBanner } from './components/ConsentBanner';
import { SettingsMenu } from './components/SettingsMenu';
import { useLanguage } from './lib/i18n';
import { Activity, Bluetooth, Cable, Play, Square, Save, Trash2, Settings, ExternalLink, AlertCircle, Upload, TrendingUp, Pause, Smartphone, FileText, LogIn, LogOut, Wifi, Target, Sun, Moon, Battery, BatteryFull, BatteryMedium, BatteryLow, BatteryWarning, Shield, Lock, EyeOff, Cloud, CloudOff, Sliders, CheckCircle2, Zap } from 'lucide-react';
import { generateClinicalReport } from './lib/reportGenerator';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { auth, db, signInWithGoogle, signInAsGuest, logOut, checkFirestoreConnectivity, collection, doc, setDoc, onSnapshot, query, where, orderBy, deleteDoc } from './firebase';
import { onAuthStateChanged, User } from 'firebase/auth';

export interface Session {
  id: string;
  userId: string;
  timestamp: number;
  duration: number;
  severity: string;
  stage: string;
  rms: number;
  frequency: number;
  data: SensorData[];
}

function App() {
  const { t } = useLanguage();
  const [isConnected, setIsConnected] = useState(false);
  const [connectionType, setConnectionType] = useState<'serial' | 'ble' | 'wifi' | 'sim' | 'mobile' | 'touch' | 'ble-touch' | 'serial-touch' | 'wifi-touch' | null>(null);
  const [batteryLevel, setBatteryLevel] = useState<number | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);
  const [data, setData] = useState<SensorData[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [recordedSessions, setRecordedSessions] = useState<Session[]>([]);
  const [permissionError, setPermissionError] = useState(false);
  const [bleStatusText, setBleStatusText] = useState<string>('');
  const [sensitivity, setSensitivity] = useState<SensitivityLevel>(() => {
    try {
      const saved = localStorage.getItem('neurotremor_sensitivity');
      if (saved === 'low' || saved === 'normal' || saved === 'high') {
        mlService.setSensitivity(saved);
        return saved;
      }
    } catch (e) {}
    mlService.setSensitivity('normal');
    return 'normal';
  });

  const [sensitivityMultiplier, setSensitivityMultiplier] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('neurotremor_sensitivity_mult');
      if (saved) {
        const val = parseFloat(saved);
        if (!isNaN(val) && val >= 0.5 && val <= 3.0) {
          mlService.setSensitivityMultiplier(val);
          return val;
        }
      }
    } catch (e) {}
    return mlService.getSensitivityMultiplier();
  });

  const handleSensitivityChange = (newLevel: SensitivityLevel) => {
    setSensitivity(newLevel);
    mlService.setSensitivity(newLevel);
    const mult = mlService.getSensitivityMultiplier();
    setSensitivityMultiplier(mult);
    try {
      localStorage.setItem('neurotremor_sensitivity', newLevel);
      localStorage.setItem('neurotremor_sensitivity_mult', mult.toString());
    } catch (e) {}
  };

  const handleSensitivityMultiplierChange = (newMult: number) => {
    const clamped = Math.max(0.5, Math.min(3.0, Number(newMult.toFixed(2))));
    setSensitivityMultiplier(clamped);
    mlService.setSensitivityMultiplier(clamped);
    try {
      localStorage.setItem('neurotremor_sensitivity_mult', clamped.toString());
    } catch (e) {}
  };

  const [mlSeverity, setMlSeverity] = useState<number>(0);
  const isInferenceRunning = useRef(false);
  const lastInferenceTime = useRef<number>(0);
  const [loadedDataset, setLoadedDataset] = useState<SensorData[] | null>(null);
  const [playbackIndex, setPlaybackIndex] = useState(0);
  const [isPlayingDataset, setIsPlayingDataset] = useState(false);
  const [isPausedDataset, setIsPausedDataset] = useState(false);
  const [isPausedRealTime, setIsPausedRealTime] = useState(false);
  const isPausedRealTimeRef = useRef(false);

  const [offsets, setOffsets] = useState<CalibrationOffsets>(() => {
    try {
      const saved = localStorage.getItem('neurotremor_calibration_offsets');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return DEFAULT_OFFSETS;
  });
  const [showCalibrationModal, setShowCalibrationModal] = useState(false);
  const [reportModalSession, setReportModalSession] = useState<Session | null>(null);
  const [securityModalTab, setSecurityModalTab] = useState<'medical' | 'privacy' | 'cookies' | 'security' | null>(null);
  const [calibrationType, setCalibrationType] = useState<'all' | 'accel' | 'gyro' | 'mag' | 'fsr'>('all');
  const [selectedSensorTab, setSelectedSensorTab] = useState<'all' | 'accel' | 'gyro' | 'mag' | 'fsr'>('all');

  const [isCalibrating, setIsCalibrating] = useState(false);
  const [calibrationTimeLeft, setCalibrationTimeLeft] = useState(0);
  const isCalibratingRef = useRef(false);
  const calibrationBuffer = useRef<SensorData[]>([]);
  const calibrationOffsets = useRef<CalibrationOffsets>(offsets);
  const calibrationTimer = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    calibrationOffsets.current = offsets;
  }, [offsets]);

  useEffect(() => {
    isPausedRealTimeRef.current = isPausedRealTime;
  }, [isPausedRealTime]);

  const [user, setUser] = useState<User | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [isHighContrast, setIsHighContrast] = useState(() => {
    try {
      const saved = localStorage.getItem('neuro_theme');
      if (saved) return saved === 'light';
    } catch (e) {}
    return document.documentElement.classList.contains('light-theme');
  });

  useEffect(() => {
    if (isHighContrast) {
      document.documentElement.classList.add('light-theme');
      document.documentElement.classList.remove('dark');
      try { localStorage.setItem('neuro_theme', 'light'); } catch (e) {}
    } else {
      document.documentElement.classList.remove('light-theme');
      document.documentElement.classList.add('dark');
      try { localStorage.setItem('neuro_theme', 'dark'); } catch (e) {}
    }
  }, [isHighContrast]);
  const [errorModal, setErrorModal] = useState<{
    title: string;
    message: string;
    actionLabel?: string;
    onAction?: () => void;
  } | null>(null);

  const [firebaseStatus, setFirebaseStatus] = useState<{
    connected: boolean;
    latencyMs?: number;
    checking: boolean;
    error?: string;
  }>({
    connected: false,
    checking: true
  });

  const runConnectivityCheck = useCallback(async () => {
    setFirebaseStatus(prev => ({ ...prev, checking: true }));
    const result = await checkFirestoreConnectivity();
    setFirebaseStatus({
      connected: result.connected,
      latencyMs: result.latencyMs,
      checking: false,
      error: result.error
    });
  }, []);

  useEffect(() => {
    runConnectivityCheck();
    const interval = setInterval(runConnectivityCheck, 60000);
    return () => clearInterval(interval);
  }, [runConnectivityCheck]);
  const [confirmModal, setConfirmModal] = useState<{title: string, message: string, onConfirm: () => void} | null>(null);
  const [showPenModal, setShowPenModal] = useState(false);
  const [isStreamingExport, setIsStreamingExport] = useState(false);
  const [exportFormat, setExportFormat] = useState<'csv'|'json'>('csv');
  const [exportDuration, setExportDuration] = useState<number>(0);
  const latestTouchRef = useRef<{x: number, y: number} | null>(null);
  
  const simulationInterval = useRef<NodeJS.Timeout | null>(null);
  const playbackInterval = useRef<NodeJS.Timeout | null>(null);
  const uiUpdateInterval = useRef<NodeJS.Timeout | null>(null);
  const startTimeRef = useRef<number>(Date.now());
  const recordingBuffer = useRef<SensorData[]>([]);
  const uiBuffer = useRef<SensorData[]>([]);
  const recordingStartTime = useRef<number>(0);

  // Data buffer limit
  const MAX_POINTS = 100;

  // Decouple high-frequency data from React state updates
  useEffect(() => {
    uiUpdateInterval.current = setInterval(() => {
      if (uiBuffer.current.length === 0) return;
      
      const newPoints = [...uiBuffer.current];
      uiBuffer.current = [];

      if (isPausedRealTimeRef.current) return;

      setData(prev => {
        const updated = [...prev, ...newPoints];
        if (updated.length > MAX_POINTS) {
          return updated.slice(updated.length - MAX_POINTS);
        }
        return updated;
      });
    }, 100); // Update UI at 10Hz

    return () => {
      if (uiUpdateInterval.current) clearInterval(uiUpdateInterval.current);
    };
  }, []);

  // Initialize ML Model
  useEffect(() => {
    mlService.initModel().then((success) => {
      if (success) {
        console.log("ML Model loaded successfully");
      }
    });
  }, []);

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setIsAuthReady(true);
    });
    return () => unsubscribe();
  }, []);

  // Load sessions from Firestore or local storage for guest
  useEffect(() => {
    if (!isAuthReady) return;
    if (!user) {
      try {
        const stored = localStorage.getItem('neurotremor_guest_sessions');
        if (stored) {
          setRecordedSessions(JSON.parse(stored));
        } else {
          setRecordedSessions([]);
        }
      } catch {
        setRecordedSessions([]);
      }
      return;
    }

    const q = query(
      collection(db, 'sessions'),
      where('userId', '==', user.uid)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const sessions: Session[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        try {
          sessions.push({
            id: data.id,
            userId: data.userId,
            timestamp: data.timestamp,
            duration: data.duration,
            severity: data.severity,
            stage: data.stage,
            rms: data.rms,
            frequency: data.frequency,
            data: JSON.parse(data.data)
          });
        } catch (e) {
          console.error("Failed to parse session data", e);
        }
      });
      // Sort in-memory to prevent Firestore composite index prerequisite failure
      sessions.sort((a, b) => b.timestamp - a.timestamp);
      setRecordedSessions(sessions);
      try {
        localStorage.setItem(`neurotremor_cached_sessions_${user.uid}`, JSON.stringify(sessions));
      } catch (e) {}
    }, (error) => {
      console.warn("Firestore query note:", error.message || error);
      try {
        const cached = localStorage.getItem(`neurotremor_cached_sessions_${user.uid}`);
        if (cached) {
          setRecordedSessions(JSON.parse(cached));
        }
      } catch (e) {}
    });

    return () => unsubscribe();
  }, [user, isAuthReady]);

  // Run ML Inference periodically
  useEffect(() => {
    if (data.length < 20) return;
    
    const now = Date.now();
    // Run inference frequently (every 50ms) to reduce latency
    if (now - lastInferenceTime.current < 50) return;
    
    lastInferenceTime.current = now;
    
    const runInference = async () => {
      if (isInferenceRunning.current) return;
      isInferenceRunning.current = true;
      try {
        const deviceType = connectionType === 'mobile' ? 'mobile' : 'pen';
        const features = mlService.extractFeatures(data, deviceType);
        const severity = await mlService.predictSeverity(data, features, deviceType);
        if (!Number.isNaN(severity)) {
          setMlSeverity(severity);
        }
      } catch (error) {
        console.error('Inference error:', error);
      } finally {
        isInferenceRunning.current = false;
      }
    };

    runInference();
  }, [data, connectionType]); // Run when data updates, throttled to 50ms

  // Metrics calculation
  const metrics = React.useMemo(() => {
    if (data.length < 10) return { rms: 0, frequency: 0, intensity: 'Normal', stage: 'Normal', recoveryRate: 0 };

    const deviceType = connectionType === 'mobile' ? 'mobile' : 'pen';
    const features = mlService.extractFeatures(data, deviceType);
    
    // Calculate immediate heuristic severity for zero-latency UI updates
    const immediateSeverity = mlService.heuristicPrediction(features, deviceType);
    
    // Use the immediate severity for the stage to ensure < 5ms latency
    const stage = mlService.getStage(immediateSeverity);
    
    let intensity = 'Normal';
    if (immediateSeverity >= 3) intensity = 'Severe';
    else if (immediateSeverity >= 2) intensity = 'Moderate';
    else if (immediateSeverity >= 1) intensity = 'Mild';

    // Calculate recovery rate compared to the very first session
    let recoveryRate = 0;
    if (recordedSessions.length > 0) {
      const firstSession = recordedSessions[recordedSessions.length - 1];
      if (firstSession.rms > 0 && !Number.isNaN(features.rms)) {
        // Recovery is positive if current RMS is lower than initial
        recoveryRate = ((firstSession.rms - features.rms) / firstSession.rms) * 100;
      }
    }

    return { 
      rms: Number.isNaN(features.rms) ? 0 : features.rms, 
      frequency: Number.isNaN(features.frequency) ? 0 : features.frequency, 
      intensity, 
      stage, 
      recoveryRate: Number.isNaN(recoveryRate) ? 0 : recoveryRate 
    };
  }, [data, recordedSessions, connectionType, sensitivity, sensitivityMultiplier]);

  const [isIframe, setIsIframe] = useState(false);

  // Audio feedback for threshold crossing
  const previousIntensityRef = useRef<string>('Normal');
  useEffect(() => {
    if (metrics.intensity !== previousIntensityRef.current) {
      if ((metrics.intensity === 'Severe' && previousIntensityRef.current !== 'Severe') || 
          (metrics.intensity === 'Moderate' && previousIntensityRef.current === 'Mild') ||
          (metrics.intensity === 'Moderate' && previousIntensityRef.current === 'Normal')) {
        audioFeedback.playThresholdCrossed(metrics.intensity);
      }
      previousIntensityRef.current = metrics.intensity;
    }
  }, [metrics.intensity]);

  // Screen Wake Lock to keep mobile monitoring continuous
  useEffect(() => {
    let wakeLock: any = null;
    
    const requestWakeLock = async () => {
      if ('wakeLock' in navigator && isConnected) {
        try {
          wakeLock = await (navigator as any).wakeLock.request('screen');
          console.log('Wake Lock is active');
        } catch (err: any) {
          if (err.name === 'NotAllowedError') {
            console.warn('Wake Lock is not allowed in this environment (e.g., iframe without permission policy).');
          } else {
            console.warn(`Wake Lock error: ${err.name}, ${err.message}`);
          }
        }
      }
    };

    const releaseWakeLock = async () => {
      if (wakeLock !== null) {
        try {
          await wakeLock.release();
          wakeLock = null;
          console.log('Wake Lock is released');
        } catch (err) {
          console.error(err);
        }
      }
    };

    if (isConnected) {
      requestWakeLock();
    } else {
      releaseWakeLock();
    }

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible' && isConnected) {
        requestWakeLock();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      releaseWakeLock();
    };
  }, [isConnected]);

  useEffect(() => {
    try {
      if (window.self !== window.top) {
        setIsIframe(true);
      }
    } catch (e) {
      setIsIframe(true);
    }
  }, []);

  const [hasGyro, setHasGyro] = useState(false);
  const [hasMag, setHasMag] = useState(false);

  const handleData = useCallback((newData: SensorData) => {
    let finalData = newData;

    if (isCalibratingRef.current) {
      calibrationBuffer.current.push(newData);
    }

    // Apply baseline offsets
    const currentOffsets = calibrationOffsets.current;
    finalData = {
      ...finalData,
      ax: finalData.ax - currentOffsets.ax,
      ay: finalData.ay - currentOffsets.ay,
      az: currentOffsets.retainGravity
        ? finalData.az - (currentOffsets.az - 9.80665)
        : finalData.az - currentOffsets.az,
      gx: finalData.gx - currentOffsets.gx,
      gy: finalData.gy - currentOffsets.gy,
      gz: finalData.gz - currentOffsets.gz,
      mx: finalData.mx - currentOffsets.mx,
      my: finalData.my - currentOffsets.my,
      mz: finalData.mz - currentOffsets.mz,
      fsr: Math.max(0, finalData.fsr - currentOffsets.fsr),
    };
    
    // Inject the latest touch coordinates from the canvas for any non-touch-only connection
    if (connectionType !== 'touch' && latestTouchRef.current) {
      finalData = {
        ...finalData,
        touchX: latestTouchRef.current.x,
        touchY: latestTouchRef.current.y
      };
    }

    uiBuffer.current.push(finalData);
    
    if (isRecording) {
      recordingBuffer.current.push(finalData);
    }
    
    if (exportService.isWriting) {
      exportService.writeData(finalData);
    }

    if (!hasGyro && (Math.abs(finalData.gx) > 0.01 || Math.abs(finalData.gy) > 0.01 || Math.abs(finalData.gz) > 0.01)) {
      setHasGyro(true);
    }
    if (!hasMag && (Math.abs(finalData.mx) > 0.01 || Math.abs(finalData.my) > 0.01 || Math.abs(finalData.mz) > 0.01)) {
      setHasMag(true);
    }
  }, [hasGyro, hasMag, isRecording, connectionType]);

  useEffect(() => {
    // Serial Listeners
    serialService.onData(handleData);
    serialService.onError((err) => {
      console.error("Serial Error:", err);
      setIsConnected(false);
      setConnectionType(null);
    });

    // BLE Listeners
    bleService.onData(handleData);
    bleService.onBattery(setBatteryLevel);
    bleService.onStatus((status) => setBleStatusText(status));
    bleService.onError((err) => {
      console.error("BLE Error:", err);
      setIsConnected(false);
      setConnectionType(null);
      setBatteryLevel(null);
    });
    bleService.onDisconnect(() => {
      console.warn("BLE Disconnected");
      setIsConnected(false);
      setConnectionType(null);
      setBatteryLevel(null);
    });

    // WiFi Listeners
    wifiService.onData(handleData);
    wifiService.onError((err) => {
      console.error("WiFi Error:", err);
      setIsConnected(false);
      setConnectionType(null);
    });
    wifiService.onDisconnect(() => {
      setIsConnected(false);
      setConnectionType(null);
    });

    // Mobile Listeners
    mobileSensorService.onData(handleData);
    mobileSensorService.onBattery(setBatteryLevel);
    mobileSensorService.onError((err) => {
      console.error("Mobile Sensor Error:", err);
      setIsConnected(false);
      setConnectionType(null);
    });
  }, [handleData]);

  // Cleanup connections only on component unmount
  useEffect(() => {
    return () => {
      serialService.disconnect();
      bleService.disconnect();
      mobileSensorService.stop();
    };
  }, []);

  const connectSerial = async (combined: boolean = false) => {
    try {
      setPermissionError(false);
      await serialService.connect();
      setIsConnected(true);
      setConnectionType(combined ? 'serial-touch' : 'serial');
      setIsSimulating(false);
    } catch (err: any) {
      console.error(err);
      if (err.name === 'SecurityError' || err.message?.includes('permissions policy')) {
        setPermissionError(true);
      } else {
        alert("Failed to connect to serial device. " + err.message);
      }
    }
  };

  const connectWiFi = async (combined: boolean = false) => {
    try {
      setPermissionError(false);
      await wifiService.connect('192.168.4.1');
      setIsConnected(true);
      setConnectionType(combined ? 'wifi-touch' : 'wifi');
      setIsSimulating(false);
    } catch (err: any) {
      console.error(err);
      if (err.name === 'SecurityError' || err.message?.includes('mixed content')) {
        setPermissionError(true);
      } else {
        alert("Failed to connect to WiFi device. " + err.message);
      }
    }
  };

  const connectBLE = async (combined: boolean = false, scanAll: boolean = false) => {
    try {
      setPermissionError(false);
      setBleStatusText("Connecting to Bluetooth...");
      await bleService.connect({ scanAll });
      setIsConnected(true);
      setConnectionType(combined ? 'ble-touch' : 'ble');
      setIsSimulating(false);
    } catch (err: any) {
      console.error("[BLE] connectBLE error:", err);
      if (err.name === 'SecurityError' || err.message?.includes('permissions policy')) {
        setPermissionError(true);
      } else if (err.name === 'NotFoundError' || err.message?.includes('cancelled') || err.message?.includes('canceled')) {
        // User dismissed the browser Bluetooth device picker modal
        console.log("[BLE] Device selection cancelled by user");
      } else {
        setErrorModal({
          title: "Bluetooth Connection Notice",
          message: `Bluetooth connection encountered an issue: ${err.message || String(err)}.\n\nQuick Solutions:\n1. Verify your ESP32 is powered on and running the updated firmware.\n2. In Windows Settings → Bluetooth & devices, remove any stale 'NeuroTremor Pen' entry and toggle Bluetooth off/on.\n3. Try reconnecting once more.`
        });
      }
    }
  };

  const connectMobile = async () => {
    try {
      setPermissionError(false);
      await mobileSensorService.start();
      setIsConnected(true);
      setConnectionType('mobile');
      setIsSimulating(false);
    } catch (err: any) {
      console.error(err);
      alert("Failed to access mobile sensors. " + err.message);
    }
  };

  const disconnect = async () => {
    if (connectionType && connectionType.includes('serial')) await serialService.disconnect();
    if (connectionType && connectionType.includes('ble')) await bleService.disconnect();
    if (connectionType && connectionType.includes('wifi')) wifiService.disconnect();
    if (connectionType === 'mobile') mobileSensorService.stop();
    if (isSimulating) {
      if (simulationInterval.current) clearInterval(simulationInterval.current);
      setIsSimulating(false);
    }
    stopDatasetPlayback();
    setIsConnected(false);
    setConnectionType(null);
    setBatteryLevel(null);
  };

  const stopDatasetPlayback = useCallback(() => {
    if (playbackInterval.current) {
      clearInterval(playbackInterval.current);
      playbackInterval.current = null;
    }
    setIsPlayingDataset(false);
    setIsPausedDataset(false);
  }, []);

  const pauseDatasetPlayback = () => {
    if (playbackInterval.current) {
      clearInterval(playbackInterval.current);
      playbackInterval.current = null;
    }
    setIsPausedDataset(true);
  };

  const resumeDatasetPlayback = () => {
    if (!loadedDataset) return;
    setIsPausedDataset(false);
    
    let index = playbackIndex;
    playbackInterval.current = setInterval(() => {
      if (index < loadedDataset.length) {
        handleData(loadedDataset[index]);
        setPlaybackIndex(index);
        index++;
      } else {
        stopDatasetPlayback();
      }
    }, 5);
  };

  const startDatasetPlayback = (dataset: SensorData[]) => {
    if (isSimulating) {
      if (simulationInterval.current) clearInterval(simulationInterval.current);
      setIsSimulating(false);
    }
    stopDatasetPlayback();
    setData([]);
    setPlaybackIndex(0);
    setIsPlayingDataset(true);
    setIsPausedDataset(false);
    setIsConnected(true);
    setConnectionType('sim'); // Use 'sim' as a placeholder for dataset playback
    
    let index = 0;
    playbackInterval.current = setInterval(() => {
      if (index < dataset.length) {
        handleData(dataset[index]);
        setPlaybackIndex(index);
        index++;
      } else {
        stopDatasetPlayback();
      }
    }, 5); // 200Hz playback
  };

  const toggleSimulation = () => {
    if (isSimulating) {
      if (simulationInterval.current) clearInterval(simulationInterval.current);
      setIsSimulating(false);
      setIsConnected(false);
      setConnectionType(null);
    } else {
      setIsSimulating(true);
      setIsConnected(true);
      setConnectionType('sim');
      startTimeRef.current = Date.now();
      
      simulationInterval.current = setInterval(() => {
        const t = (Date.now() - startTimeRef.current) / 1000;
        // Simulate Parkinson's tremor (approx 5Hz) + some noise + gravity
        const tremor = Math.sin(t * 5 * Math.PI * 2) * 0.5; // 5Hz tremor
        const noise = (Math.random() - 0.5) * 0.1;
        
        const fakeData: SensorData = {
          timestamp: Date.now(),
          ax: tremor + noise,
          ay: noise + 0.2,
          az: 9.8 + noise, // Gravity
          gx: Math.cos(t * 5 * Math.PI * 2) * 20 + noise,
          gy: noise,
          gz: noise,
          mx: Math.sin(t) * 50,
          my: Math.cos(t) * 50,
          mz: noise * 10,
          fsr: Math.abs(Math.sin(t) * 500) + 100 // Fluctuating grip pressure
        };
        handleData(fakeData);
      }, 5); // 200Hz update rate
    }
  };

  const clearData = () => {
    setData([]);
  };

  const startCalibration = (
    type: 'all' | 'accel' | 'gyro' | 'mag' | 'fsr' = 'all', 
    retainGrav: boolean = offsets.retainGravity
  ) => {
    if (isCalibratingRef.current || !isConnected) return;
    
    isCalibratingRef.current = true;
    setIsCalibrating(true);
    setCalibrationType(type);
    setCalibrationTimeLeft(3);
    calibrationBuffer.current = [];

    let timeLeft = 3;
    calibrationTimer.current = setInterval(() => {
      timeLeft -= 1;
      setCalibrationTimeLeft(timeLeft);
      if (timeLeft <= 0) {
        if (calibrationTimer.current) clearInterval(calibrationTimer.current);
        isCalibratingRef.current = false;
        setIsCalibrating(false);
        
        if (calibrationBuffer.current.length > 0) {
          const count = calibrationBuffer.current.length;
          const sum = calibrationBuffer.current.reduce((acc, val) => {
            acc.ax += val.ax; acc.ay += val.ay; acc.az += val.az;
            acc.gx += val.gx; acc.gy += val.gy; acc.gz += val.gz;
            acc.mx += val.mx; acc.my += val.my; acc.mz += val.mz;
            acc.fsr += val.fsr;
            return acc;
          }, {ax: 0, ay: 0, az: 0, gx: 0, gy: 0, gz: 0, mx: 0, my: 0, mz: 0, fsr: 0});
          
          const mean = {
            ax: sum.ax / count,
            ay: sum.ay / count,
            az: sum.az / count,
            gx: sum.gx / count,
            gy: sum.gy / count,
            gz: sum.gz / count,
            mx: sum.mx / count,
            my: sum.my / count,
            mz: sum.mz / count,
            fsr: sum.fsr / count,
          };

          setOffsets(prev => {
            let nextOffsets: CalibrationOffsets = { ...prev, retainGravity: retainGrav };
            if (type === 'all') {
              nextOffsets = {
                ax: mean.ax,
                ay: mean.ay,
                az: mean.az,
                gx: mean.gx,
                gy: mean.gy,
                gz: mean.gz,
                mx: mean.mx,
                my: mean.my,
                mz: mean.mz,
                fsr: mean.fsr,
                retainGravity: retainGrav,
              };
            } else if (type === 'accel') {
              nextOffsets.ax = mean.ax;
              nextOffsets.ay = mean.ay;
              nextOffsets.az = mean.az;
              nextOffsets.retainGravity = retainGrav;
            } else if (type === 'gyro') {
              nextOffsets.gx = mean.gx;
              nextOffsets.gy = mean.gy;
              nextOffsets.gz = mean.gz;
            } else if (type === 'mag') {
              nextOffsets.mx = mean.mx;
              nextOffsets.my = mean.my;
              nextOffsets.mz = mean.mz;
            } else if (type === 'fsr') {
              nextOffsets.fsr = mean.fsr;
            }

            calibrationOffsets.current = nextOffsets;
            try {
              localStorage.setItem('neurotremor_calibration_offsets', JSON.stringify(nextOffsets));
            } catch (e) {}
            return nextOffsets;
          });
        }
      }
    }, 1000);
  };

  const handleSaveOffsets = (newOffsets: CalibrationOffsets) => {
    setOffsets(newOffsets);
    calibrationOffsets.current = newOffsets;
    try {
      localStorage.setItem('neurotremor_calibration_offsets', JSON.stringify(newOffsets));
    } catch (e) {}
  };

  const exportSession = () => {
    if (data.length === 0) return;
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tremor-session-${new Date().toISOString()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleSignInAsGuest = async () => {
    try {
      await signInAsGuest();
    } catch (error: any) {
      console.error("Guest sign-in failed:", error);
      setErrorModal({
        title: "Guest Cloud Mode",
        message: `Could not activate guest session: ${error.message || String(error)}.`
      });
    }
  };

  const handleSignIn = async () => {
    try {
      await signInWithGoogle();
    } catch (error: any) {
      if (error.code === 'auth/popup-closed-by-user') {
        return; // User intentionally closed the popup, ignore
      }
      console.error("Sign in failed:", error);
      setErrorModal({
        title: "Sign In Notice",
        message: `Authentication prompt could not be completed (${error.message || 'Popup blocked or cookie restriction'}).\n\nYou can continue immediately with Guest Cloud Mode to sync and store all patient data in Firebase Firestore without requiring Google credentials.`,
        actionLabel: "Continue as Guest (Cloud Sync)",
        onAction: async () => {
          setErrorModal(null);
          await handleSignInAsGuest();
        }
      });
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-black text-slate-800 dark:text-zinc-200 font-sans selection:bg-emerald-500/30 transition-colors">
      
      {/* Error Modal */}
      {errorModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="bg-white dark:bg-slate-900 border border-red-300 dark:border-red-900/50 rounded-lg max-w-md w-full p-5 shadow-xl">
            <div className="flex items-center space-x-2.5 mb-3 text-red-600 dark:text-red-400">
              <AlertCircle size={22} />
              <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-900 dark:text-slate-100">{errorModal.title}</h3>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400 mb-5 leading-relaxed">
              {errorModal.message}
            </p>
            <div className="flex justify-end space-x-2">
              <button 
                onClick={() => setErrorModal(null)}
                className="px-3.5 py-1.5 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 text-xs font-medium transition-colors shadow-2xs"
              >
                {t('dismiss')}
              </button>
              {errorModal.actionLabel && errorModal.onAction && (
                <button
                  onClick={() => errorModal.onAction!()}
                  className="px-3.5 py-1.5 rounded-md bg-sky-700 hover:bg-sky-800 text-white text-xs font-medium transition-colors shadow-2xs flex items-center gap-1.5"
                >
                  <Zap size={13} />
                  <span>{errorModal.actionLabel}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Confirm Modal */}
      {confirmModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-900/50 rounded-lg max-w-md w-full p-5 shadow-xl">
            <div className="flex items-center space-x-2.5 mb-3 text-amber-600 dark:text-amber-400">
              <AlertCircle size={22} />
              <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-900 dark:text-slate-100">{confirmModal.title}</h3>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400 mb-5 leading-relaxed">
              {confirmModal.message}
            </p>
            <div className="flex justify-end space-x-2">
              <button 
                onClick={() => setConfirmModal(null)}
                className="px-3.5 py-1.5 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 text-xs font-medium transition-colors border border-slate-200 dark:border-slate-700"
              >
                {t('cancel')}
              </button>
              <button 
                onClick={() => {
                  confirmModal.onConfirm();
                  setConfirmModal(null);
                }}
                className="px-3.5 py-1.5 rounded-md bg-red-600 hover:bg-red-700 text-white text-xs font-medium transition-colors shadow-2xs"
              >
                {t('confirm')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Pen/Touch Input Selection Modal */}
      {showPenModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg max-w-md w-full p-5 shadow-xl">
            <div className="flex items-center space-x-2.5 mb-2 text-sky-700 dark:text-sky-400">
              <FileText size={22} />
              <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-900 dark:text-slate-100">{t('connectPenOrTouchPad')}</h3>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400 mb-4 leading-relaxed">
              {t('chooseInputMethod')}
            </p>
            <div className="flex flex-col space-y-2">
              <button 
                onClick={() => {
                  setShowPenModal(false);
                  setIsConnected(true);
                  setConnectionType('touch');
                  setIsSimulating(false);
                  setData([]);
                  setConfirmModal({
                    title: t('useDeviceTouchPad'),
                    message: t('drawDirectlyMouse'),
                    onConfirm: () => {}
                  });
                }}
                className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-md bg-white hover:bg-slate-50 text-slate-800 dark:bg-slate-850 dark:hover:bg-slate-800 dark:text-white text-xs font-medium transition-colors border border-slate-200 dark:border-slate-800 shadow-2xs"
              >
                <div className="bg-slate-100 dark:bg-slate-800 p-1.5 rounded-md text-slate-600 dark:text-slate-300">
                  <FileText size={16} />
                </div>
                <div className="text-left flex-1">
                  <div className="font-semibold text-slate-900 dark:text-slate-100">{t('useDeviceTouchPad')}</div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 font-normal">{t('drawDirectlyMouse')}</div>
                </div>
              </button>
              
              <button 
                onClick={() => {
                  setShowPenModal(false);
                  connectBLE();
                }}
                className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-md bg-white hover:bg-slate-50 text-slate-800 dark:bg-slate-850 dark:hover:bg-slate-800 dark:text-white text-xs font-medium transition-colors border border-slate-200 dark:border-slate-800 shadow-2xs"
              >
                <div className="bg-sky-50 dark:bg-sky-950/50 p-1.5 rounded-md text-sky-700 dark:text-sky-400">
                  <Bluetooth size={16} />
                </div>
                <div className="text-left flex-1">
                  <div className="font-semibold text-slate-900 dark:text-slate-100">{t('connectCustomEsp32')}</div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 font-normal">{t('connectViaBle')}</div>
                </div>
              </button>
              
              <button 
                onClick={() => {
                  setShowPenModal(false);
                  connectBLE(true);
                  setConfirmModal({
                    title: t('combinedModeBle'),
                    message: t('useBleEsp32TouchPad'),
                    onConfirm: () => {}
                  });
                }}
                className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-md bg-white hover:bg-slate-50 text-slate-800 dark:bg-slate-850 dark:hover:bg-slate-800 dark:text-white text-xs font-medium transition-colors border border-slate-200 dark:border-slate-800 shadow-2xs"
              >
                <div className="bg-sky-50 dark:bg-sky-950/50 p-1.5 rounded-md text-sky-700 dark:text-sky-400">
                  <div className="flex items-center space-x-1">
                    <Bluetooth size={14} />
                    <FileText size={14} />
                  </div>
                </div>
                <div className="text-left flex-1">
                  <div className="font-semibold text-slate-900 dark:text-slate-100">{t('combinedModeBle')}</div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 font-normal">{t('useBleEsp32TouchPad')}</div>
                </div>
              </button>
              
              <button 
                onClick={() => {
                  setShowPenModal(false);
                  connectSerial(true);
                  setConfirmModal({
                    title: t('combinedModeUsb'),
                    message: t('useUsbEsp32TouchPad'),
                    onConfirm: () => {}
                  });
                }}
                className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-md bg-white hover:bg-slate-50 text-slate-800 dark:bg-slate-850 dark:hover:bg-slate-800 dark:text-white text-xs font-medium transition-colors border border-slate-200 dark:border-slate-800 shadow-2xs"
              >
                <div className="bg-sky-50 dark:bg-sky-950/50 p-1.5 rounded-md text-sky-700 dark:text-sky-400">
                  <div className="flex items-center space-x-1">
                    <Cable size={14} />
                    <FileText size={14} />
                  </div>
                </div>
                <div className="text-left flex-1">
                  <div className="font-semibold text-slate-900 dark:text-slate-100">{t('combinedModeUsb')}</div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 font-normal">{t('useUsbEsp32TouchPad')}</div>
                </div>
              </button>
              
              <button 
                onClick={() => setShowPenModal(false)}
                className="w-full mt-2 px-3 py-1.5 rounded-md bg-transparent hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 text-xs font-medium transition-colors"
              >
                {t('cancel')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Iframe Warning Banner */}
      {isIframe && (
        <div className="bg-amber-50 dark:bg-amber-950/40 border-b border-amber-200 dark:border-amber-900/50 px-4 py-2 text-center">
          <p className="text-xs text-amber-900 dark:text-amber-300 flex items-center justify-center gap-1.5">
            <AlertCircle size={14} />
            <span>{t('hardwareAccessRestricted')}</span>
            <a 
              href={window.location.href} 
              target="_blank" 
              rel="noopener noreferrer"
              className="underline font-medium hover:text-black dark:hover:text-white flex items-center gap-1"
            >
              {t('openInNewTab')} <ExternalLink size={11} />
            </a>
          </p>
        </div>
      )}

      {/* Permission Error Modal */}
      {permissionError && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="bg-white dark:bg-slate-900 border border-red-300 dark:border-red-900/50 rounded-lg max-w-md w-full p-5 shadow-xl">
            <div className="flex items-center space-x-2.5 mb-3 text-red-600 dark:text-red-400">
              <AlertCircle size={22} />
              <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-900 dark:text-slate-100">{t('connectionBlocked')}</h3>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400 mb-4 leading-relaxed">
              {t('browserBlockedAccess')}
            </p>
            <div className="bg-slate-50 dark:bg-slate-950/50 rounded-md p-3 mb-4 border border-slate-200 dark:border-slate-800">
              <p className="text-xs text-slate-700 dark:text-slate-300 mb-1.5 font-medium">{t('toFixThis')}:</p>
              <ol className="list-decimal list-inside space-y-1 text-slate-600 dark:text-slate-400 text-xs">
                <li>{t('clickOpenNewTab')}</li>
                <li>{t('connectDeviceNewWindow')}</li>
              </ol>
            </div>
            <div className="flex justify-end space-x-2">
              <button 
                onClick={() => setPermissionError(false)}
                className="px-3.5 py-1.5 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 text-xs font-medium transition-colors border border-slate-200 dark:border-slate-700"
              >
                {t('dismiss')}
              </button>
              <a 
                href={window.location.href} 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-md bg-sky-700 hover:bg-sky-800 text-white text-xs font-medium transition-colors shadow-2xs"
              >
                <span>{t('openInNewTab')}</span>
                <ExternalLink size={13} />
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="border-b border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/90 backdrop-blur-md sticky top-0 z-50 transition-colors shadow-xs">
        <div className="max-w-7xl mx-auto px-4 py-2.5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center space-x-3 w-full sm:w-auto justify-between sm:justify-start">
            <div className="flex items-center space-x-2.5">
              <SettingsMenu
                user={user}
                onSignIn={handleSignIn}
                onSignInAsGuest={handleSignInAsGuest}
                onSignOut={logOut}
                onOpenSecurityModal={(tab) => setSecurityModalTab(tab || 'medical')}
                isHighContrast={isHighContrast}
                onToggleHighContrast={() => setIsHighContrast(!isHighContrast)}
                onOpenCalibration={() => setShowCalibrationModal(true)}
                isCalibrating={isCalibrating}
                hasOffsets={offsets.ax !== 0 || offsets.gx !== 0 || offsets.mx !== 0}
                firebaseStatus={firebaseStatus}
                onTestFirebase={runConnectivityCheck}
                sensitivity={sensitivity}
                sensitivityMultiplier={sensitivityMultiplier}
                onChangeSensitivity={handleSensitivityChange}
                onChangeSensitivityMultiplier={handleSensitivityMultiplierChange}
              />
              <div className="flex items-center space-x-2">
                <div className="w-6 h-6 bg-sky-700 rounded flex items-center justify-center shadow-2xs text-white">
                  <Activity size={15} />
                </div>
                <div>
                  <h1 className="text-sm font-semibold tracking-wide uppercase text-slate-900 dark:text-slate-100 font-mono">NeuroTremor</h1>
                  <span className="text-[10px] text-slate-400 dark:text-slate-500 font-mono block -mt-0.5 leading-none">QMA-SYSTEM</span>
                </div>
              </div>
            </div>
            
            {/* Mobile-only status pill */}
            <div className={`sm:hidden flex items-center space-x-1.5 px-2 py-0.5 rounded-full text-[10px] font-mono border ${isConnected ? 'bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/40 dark:border-emerald-800/60 dark:text-emerald-300' : 'bg-slate-50 border-slate-200 text-slate-600 dark:bg-slate-800/60 dark:border-slate-700 dark:text-slate-400'}`}>
              <div className={`w-1.5 h-1.5 rounded-full ${isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400 dark:bg-slate-500'}`} />
              <span>{isConnected ? (connectionType === 'touch' ? t('touchPadMode') : (connectionType && connectionType.includes('touch')) ? t('combinedMode') : connectionType === 'ble' ? (bleService.getDeviceName() || 'BLE').toUpperCase() : connectionType === 'mobile' ? t('mobile') : t('connected')) : t('disconnected')}</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center sm:justify-end gap-2 w-full sm:w-auto">
            {/* Desktop status pill */}
            <div className={`hidden sm:flex items-center space-x-2 px-2.5 py-1 rounded-full text-xs font-mono border ${isConnected ? 'bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/40 dark:border-emerald-800/60 dark:text-emerald-300' : 'bg-slate-50 border-slate-200 text-slate-600 dark:bg-slate-800/60 dark:border-slate-700 dark:text-slate-400'}`}>
              <div className={`w-1.5 h-1.5 rounded-full ${isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400 dark:bg-slate-500'}`} />
              <span>{isConnected ? (isPlayingDataset ? t('playingDataset') : isSimulating ? t('simulating') : connectionType === 'touch' ? t('touchPadMode') : (connectionType && connectionType.includes('touch')) ? t('combinedMode') : connectionType === 'ble' ? (bleService.getDeviceName() || 'CUSTOM BLE DEV').toUpperCase() : connectionType === 'wifi' ? t('wifiConnected') : connectionType === 'mobile' ? t('mobileSensors') : t('usbConnected')) : t('disconnected')}</span>
            </div>

            {/* Cloud Sync Status Indicator */}
            {firebaseStatus.connected ? (
              <div className="hidden lg:flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-xs font-mono border bg-emerald-50 border-emerald-200 text-emerald-800 dark:bg-emerald-950/40 dark:border-emerald-800/60 dark:text-emerald-300" title={`Firestore Connected (${firebaseStatus.latencyMs ?? 0}ms)`}>
                <Cloud size={13} className="text-emerald-600 dark:text-emerald-400" />
                <span>CLOUD SYNC</span>
              </div>
            ) : (
              <button 
                onClick={runConnectivityCheck}
                className="hidden lg:flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-xs font-mono border bg-amber-50 border-amber-200 text-amber-800 dark:bg-amber-950/40 dark:border-amber-800/60 dark:text-amber-300 hover:bg-amber-100 dark:hover:bg-amber-900/60 cursor-pointer transition-colors" 
                title="Firebase connection checking/offline - click to test ping"
              >
                <CloudOff size={13} className="text-amber-600 dark:text-amber-400" />
                <span>{firebaseStatus.checking ? 'CONNECTING...' : 'LOCAL CACHE'}</span>
              </button>
            )}
            
            {batteryLevel !== null && isConnected && (connectionType === 'ble' || connectionType === 'mobile' || connectionType === 'ble-touch') && (
              <div className="flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-xs font-mono border bg-slate-50 border-slate-200 text-slate-700 dark:bg-slate-800/60 dark:border-slate-700 dark:text-slate-300" title="Device Battery Level">
                <Battery size={13} className={batteryLevel > 20 ? "text-emerald-600 dark:text-emerald-400" : "text-red-600 dark:text-red-400"} />
                <span>{batteryLevel}%</span>
              </div>
            )}

            {!isConnected ? (
              <div className="flex flex-wrap justify-center gap-1.5">
                <DatasetUploader 
                  onDataLoaded={(dataset) => {
                    setLoadedDataset(dataset);
                    startDatasetPlayback(dataset);
                  }}
                  onError={(msg) => setErrorModal({ title: "Dataset Error", message: msg })}
                />
                <button 
                  onClick={connectSerial}
                  className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white dark:bg-slate-100 dark:text-slate-900 dark:hover:bg-slate-200 rounded-md transition-colors text-xs font-medium shadow-2xs"
                  title="Connect via USB Cable"
                >
                  <Cable size={14} />
                  <span className="hidden md:inline">{t('usb')}</span>
                </button>
                <button 
                  onClick={() => connectBLE(false)}
                  className="flex items-center space-x-1.5 px-3 py-1.5 bg-sky-700 hover:bg-sky-800 text-white rounded-md transition-colors text-xs font-medium shadow-2xs"
                  title="Connect via Bluetooth Low Energy (BLE)"
                >
                  <Bluetooth size={14} />
                  <span className="hidden md:inline">Bluetooth</span>
                </button>
                <button 
                  onClick={connectMobile}
                  className="flex items-center space-x-1.5 px-3 py-1.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 dark:text-slate-200 dark:border-slate-700 rounded-md transition-colors text-xs font-medium shadow-2xs"
                  title="Use Mobile Sensors"
                >
                  <Smartphone size={14} />
                  <span className="hidden md:inline">{t('mobile')}</span>
                </button>
                <button 
                  onClick={() => setShowPenModal(true)}
                  className="flex items-center space-x-1.5 px-3 py-1.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 dark:text-slate-200 dark:border-slate-700 rounded-md transition-colors text-xs font-medium shadow-2xs"
                  title="Connect Pen or Touch Pad"
                >
                  <FileText size={14} />
                  <span className="hidden md:inline">{t('penTouch')}</span>
                </button>
                <button 
                  onClick={toggleSimulation}
                  className="flex items-center space-x-1.5 px-3 py-1.5 bg-sky-50 text-sky-800 border border-sky-200 hover:bg-sky-100 dark:bg-sky-950/50 dark:text-sky-300 dark:border-sky-800/60 rounded-md transition-colors text-xs font-medium shadow-2xs"
                  title="Run Demo Simulation"
                >
                  <Play size={14} />
                  <span className="hidden md:inline">{t('demo')}</span>
                </button>
              </div>
            ) : (
              <div className="flex space-x-1.5">
                {!isPlayingDataset && (
                  <button
                    onClick={() => setShowCalibrationModal(true)}
                    className={`flex items-center space-x-1.5 px-3 py-1.5 border rounded-md transition-colors text-xs font-medium shadow-2xs ${
                      isCalibrating 
                        ? 'bg-amber-50 border-amber-300 text-amber-800 dark:bg-amber-950/40 dark:border-amber-800 dark:text-amber-300 animate-pulse' 
                        : (offsets.ax !== 0 || offsets.gx !== 0 || offsets.mx !== 0)
                        ? 'bg-emerald-50 border-emerald-200 text-emerald-800 dark:bg-emerald-950/40 dark:border-emerald-800 dark:text-emerald-300'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50 dark:bg-slate-800 dark:text-slate-200 dark:border-slate-700 dark:hover:bg-slate-750'
                    }`}
                    title="Calibrate IMU Sensors & Zero Biases"
                  >
                    <Target size={14} className={isCalibrating ? 'animate-spin' : ''} />
                    <span>{isCalibrating ? `${t('calibrating')} (${calibrationTimeLeft}s)` : t('calibrate')}</span>
                  </button>
                )}
                <button 
                  onClick={disconnect}
                  className="flex items-center space-x-1.5 px-3 py-1.5 bg-red-50 text-red-700 border border-red-200 rounded-md hover:bg-red-100 dark:bg-red-950/30 dark:text-red-400 dark:border-red-900/50 transition-colors text-xs font-medium shadow-2xs"
                >
                  <Square size={14} />
                  <span>{isPlayingDataset ? t('stopPlayback') : isSimulating ? t('stopDemo') : t('disconnect')}</span>
                </button>
              </div>
            )}

            <div className="h-5 w-px bg-slate-200 dark:border-slate-800 hidden sm:block mx-0.5"></div>

            <LanguageSelector />

            <button
              onClick={() => setIsHighContrast(!isHighContrast)}
              className="flex items-center space-x-1.5 px-2.5 py-1.5 bg-white text-slate-700 border border-slate-200 dark:bg-slate-900 dark:text-slate-300 dark:border-slate-800 rounded-md hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-xs font-medium shadow-2xs"
              title={isHighContrast ? "Switch to Dark Mode" : "Switch to High Contrast Light Mode"}
            >
              {isHighContrast ? <Moon size={14} /> : <Sun size={14} />}
              <span className="hidden md:inline">{isHighContrast ? t('dark') : t('light')}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        
        {isPlayingDataset && loadedDataset && (
          <div className="mb-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-3.5 shadow-2xs">
            <div className="flex items-center justify-between mb-3">
              <div>
                <span className="text-[11px] font-semibold text-sky-800 dark:text-sky-400 uppercase tracking-wider font-mono">{t('datasetPlaybackProgress')}</span>
                <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-mono">{playbackIndex + 1} / {loadedDataset.length} {t('points')}</div>
              </div>
              <div className="flex space-x-1.5">
                {isPausedDataset ? (
                  <button 
                    onClick={resumeDatasetPlayback}
                    className="flex items-center space-x-1.5 px-3 py-1.5 bg-sky-700 hover:bg-sky-800 text-white rounded-md transition-colors text-xs font-medium shadow-2xs"
                  >
                    <Play size={13} />
                    <span>{t('resume')}</span>
                  </button>
                ) : (
                  <button 
                    onClick={pauseDatasetPlayback}
                    className="flex items-center space-x-1.5 px-3 py-1.5 bg-white text-slate-700 border border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 rounded-md hover:bg-slate-50 dark:hover:bg-slate-750 transition-colors text-xs font-medium shadow-2xs"
                  >
                    <Pause size={13} />
                    <span>{t('pause')}</span>
                  </button>
                )}
                <button 
                  onClick={stopDatasetPlayback}
                  className="flex items-center space-x-1.5 px-3 py-1.5 bg-red-50 text-red-700 border border-red-200 dark:bg-red-950/30 dark:text-red-400 dark:border-red-900/50 rounded-md hover:bg-red-100 dark:hover:bg-red-950/50 transition-colors text-xs font-medium shadow-2xs"
                >
                  <Square size={13} />
                  <span>{t('stop')}</span>
                </button>
              </div>
            </div>
            <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div 
                className="bg-sky-600 h-full transition-all duration-300 ease-linear"
                style={{ width: `${((playbackIndex + 1) / loadedDataset.length) * 100}%` }}
              />
            </div>
          </div>
        )}

        {isPausedDataset && (
          <DatasetSummary 
            data={data} 
            title={t('analysisUntilPause')}
            onPlay={resumeDatasetPlayback}
            onClear={() => {
              setLoadedDataset(null);
              stopDatasetPlayback();
            }}
            onRequestReport={(sess) => setReportModalSession(sess)}
            isDark={!isHighContrast}
          />
        )}

        {loadedDataset && !isPlayingDataset && (
          <DatasetSummary 
            data={loadedDataset} 
            onPlay={() => startDatasetPlayback(loadedDataset)}
            onClear={() => setLoadedDataset(null)}
            onRequestReport={(sess) => setReportModalSession(sess)}
            isDark={!isHighContrast}
          />
        )}

        {isConnected && connectionType !== 'sim' && data.length > 0 && (
          <div className="mb-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-3.5 shadow-2xs">
            <div className="flex items-center justify-between mb-2">
              <div>
                <span className="text-[11px] font-semibold text-sky-800 dark:text-sky-400 uppercase tracking-wider font-mono">{t('realtimeAnalysisLive')}</span>
                <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{t('collectingDataFrom')} {connectionType?.includes('touch') ? t('touchPadAndPen') : connectionType === 'mobile' ? t('mobile') : t('device')}</div>
              </div>
              <div className="flex space-x-1.5">
                {isPausedRealTime ? (
                  <button 
                    onClick={() => setIsPausedRealTime(false)}
                    className="flex items-center space-x-1.5 px-3 py-1.5 bg-sky-700 hover:bg-sky-800 text-white rounded-md transition-colors text-xs font-medium shadow-2xs"
                  >
                    <Play size={13} />
                    <span>{t('resume')}</span>
                  </button>
                ) : (
                  <button 
                    onClick={() => setIsPausedRealTime(true)}
                    className="flex items-center space-x-1.5 px-3 py-1.5 bg-white text-slate-700 border border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 rounded-md hover:bg-slate-50 dark:hover:bg-slate-750 transition-colors text-xs font-medium shadow-2xs"
                  >
                    <Pause size={13} />
                    <span>{t('pause')}</span>
                  </button>
                )}
                <button 
                  onClick={() => {
                    setIsPausedRealTime(false);
                    setLoadedDataset(data);
                    disconnect();
                  }}
                  className="flex items-center space-x-1.5 px-3 py-1.5 bg-red-50 text-red-700 border border-red-200 dark:bg-red-950/30 dark:text-red-400 dark:border-red-900/50 rounded-md hover:bg-red-100 dark:hover:bg-red-950/50 transition-colors text-xs font-medium shadow-2xs"
                >
                  <Square size={13} />
                  <span>{t('stopAnalysis')}</span>
                </button>
              </div>
            </div>
            {isPausedRealTime && (
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 italic">{t('chartPausedNotice')}</p>
            )}
          </div>
        )}

        {isConnected && isPausedRealTime && (
          <DatasetSummary 
            data={data} 
            title={t('analysisUntilPause')}
            onPlay={() => setIsPausedRealTime(false)}
            onClear={() => {
               // Do nothing for clear during live
            }}
            onRequestReport={(sess) => setReportModalSession(sess)}
            isDark={!isHighContrast}
          />
        )}
        
        {/* Metrics */}
        <TremorAnalysis metrics={metrics} />

        {/* Recovery Trend Section */}
        <div className="mb-6">
          <RecoveryTrendChart sessions={recordedSessions} isDark={!isHighContrast} />
        </div>

        {isConnected && (
          <TouchPadCanvas 
            onData={handleData} 
            mode={connectionType === 'touch' ? 'touch' : 'combined'}
            onTouchUpdate={(x, y, pressure) => {
              latestTouchRef.current = { x, y };
            }}
          />
        )}

        {/* Sensor Graph Selector & Sensitivity Action Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2.5 mb-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2 rounded-lg shadow-2xs">
          <div className="flex flex-wrap items-center gap-1">
            <span className="text-[10px] font-semibold uppercase text-slate-500 dark:text-slate-400 mr-1.5 tracking-wider font-mono">{t('sensors')}</span>
            {[
              { id: 'all', label: t('allSensors') },
              { id: 'accel', label: t('accelerometer') },
              { id: 'gyro', label: t('gyroscope') },
              { id: 'mag', label: t('magnetometer') },
              { id: 'fsr', label: t('gripPressure') },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setSelectedSensorTab(tab.id as any)}
                className={`px-2.5 py-1 rounded-md text-xs font-medium transition-all ${
                  selectedSensorTab === tab.id
                    ? 'bg-slate-800 text-white dark:bg-slate-700 dark:text-slate-100 shadow-2xs font-semibold'
                    : 'bg-slate-50 text-slate-700 hover:text-slate-900 hover:bg-slate-100 border border-slate-200 dark:bg-slate-850 dark:text-slate-400 dark:hover:text-slate-200 dark:border-slate-750 dark:hover:bg-slate-800'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Sensitivity Presets & Continuous Tuning Controller */}
            <div className="flex items-center gap-1.5 bg-slate-50 dark:bg-slate-850 p-1 rounded-md border border-slate-200 dark:border-slate-750 text-xs shadow-2xs">
              <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400 uppercase font-semibold px-1" title="Tremor Detection Sensitivity Multiplier">
                Sensitivity:
              </span>
              <div className="flex items-center gap-1">
                {(['low', 'normal', 'high'] as const).map((lvl) => (
                  <button
                    key={lvl}
                    onClick={() => handleSensitivityChange(lvl)}
                    className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                      sensitivity === lvl
                        ? 'bg-sky-700 text-white shadow-2xs font-semibold'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                    }`}
                    title={
                      lvl === 'low'
                        ? 'Dampened (Low - 2.0x): Strongly filters handwriting and voluntary arm movement'
                        : lvl === 'normal'
                        ? 'Normal (Optimized - 1.35x): Balanced clinical baseline for Parkinsonian tremor'
                        : 'High (Sensitive - 0.9x): Sensitive to subtle micro-tremors and fine finger oscillations'
                    }
                  >
                    {lvl === 'low' ? 'Low (Writing)' : lvl === 'normal' ? 'Normal (Opt)' : 'High'}
                  </button>
                ))}
              </div>
              <div className="h-3 w-px bg-slate-200 dark:bg-slate-700 hidden sm:block"></div>
              <div className="hidden sm:flex items-center gap-1.5 pl-0.5" title="Fine-tune sensitivity threshold multiplier">
                <input
                  type="range"
                  min="0.5"
                  max="3.0"
                  step="0.05"
                  value={sensitivityMultiplier}
                  onChange={(e) => handleSensitivityMultiplierChange(parseFloat(e.target.value))}
                  className="w-16 h-1 accent-sky-700 dark:accent-sky-500 cursor-pointer rounded bg-slate-200 dark:bg-slate-700"
                  title={`Fine Tuning: ${sensitivityMultiplier.toFixed(2)}x`}
                />
                <span className="text-[10px] font-mono font-medium text-slate-700 dark:text-slate-300">
                  {sensitivityMultiplier.toFixed(2)}x
                </span>
              </div>
            </div>

            <button
              onClick={() => setShowCalibrationModal(true)}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 dark:text-slate-300 dark:border-slate-700 transition-colors shadow-2xs"
              title="Open IMU Calibration & Zeroing Panel"
            >
              <Target size={13} className={isCalibrating ? 'animate-spin' : ''} />
              <span>{isCalibrating ? `${t('calibrating')} (${calibrationTimeLeft}s)` : t('calibrateSensors')}</span>
            </button>
          </div>
        </div>

        {/* Sensor Charts Grid */}
        <div className={`grid gap-6 mb-8 ${selectedSensorTab === 'all' ? 'grid-cols-1 lg:grid-cols-2' : 'grid-cols-1'}`}>
          {(selectedSensorTab === 'all' || selectedSensorTab === 'accel') && (
            <LiveChart 
              title={t('accelerometer')} 
              data={data}
              isDark={!isHighContrast}
              dataKeys={[
                { key: 'ax', color: '#ef4444', name: t('xAxis') },
                { key: 'ay', color: '#16a34a', name: t('yAxis') },
                { key: 'az', color: '#2563eb', name: t('zAxis') },
              ]}
              unit="m/s²"
              calibratedDomain={[-16, 16]}
              scalePresets={[
                { label: '±16 m/s²', domain: [-16, 16] },
                { label: 'Auto Fit', domain: ['auto', 'auto'] },
                { label: '±25 m/s²', domain: [-25, 25] },
                { label: '±2 G', domain: [-2, 2] },
              ]}
              onQuickCalibrate={() => startCalibration('accel')}
              calibrateLabel={t('calibrateAccelerometer')}
              isCalibrated={offsets.ax !== 0 || offsets.ay !== 0 || offsets.az !== 0}
            />
          )}

          {(selectedSensorTab === 'all' || selectedSensorTab === 'gyro') && (
            <LiveChart 
              title={t('gyroscope')} 
              data={data}
              isDark={!isHighContrast}
              dataKeys={[
                { key: 'gx', color: '#ea580c', name: t('xRotation') },
                { key: 'gy', color: '#9333ea', name: t('yRotation') },
                { key: 'gz', color: '#0891b2', name: t('zRotation') },
              ]}
              unit="°/s"
              scalePresets={[
                { label: 'Auto Fit', domain: ['auto', 'auto'] },
                { label: '±100 °/s', domain: [-100, 100] },
                { label: '±250 °/s', domain: [-250, 250] },
                { label: '±500 °/s', domain: [-500, 500] },
              ]}
              onQuickCalibrate={() => startCalibration('gyro')}
              calibrateLabel={t('zeroGyroDrift')}
              isCalibrated={offsets.gx !== 0 || offsets.gy !== 0 || offsets.gz !== 0}
            />
          )}

          {(selectedSensorTab === 'all' || selectedSensorTab === 'mag') && (
            <LiveChart 
              title={t('magnetometer')} 
              data={data}
              isDark={!isHighContrast}
              dataKeys={[
                { key: 'mx', color: '#db2777', name: t('xMag') },
                { key: 'my', color: '#7c3aed', name: t('yMag') },
                { key: 'mz', color: '#2563eb', name: t('zMag') },
              ]}
              unit="µT"
              scalePresets={[
                { label: 'Auto Fit', domain: ['auto', 'auto'] },
                { label: '±80 µT', domain: [-80, 80] },
                { label: '±150 µT', domain: [-150, 150] },
              ]}
              onQuickCalibrate={() => startCalibration('mag')}
              calibrateLabel={t('calibrateMagnetometer')}
              isCalibrated={offsets.mx !== 0 || offsets.my !== 0 || offsets.mz !== 0}
            />
          )}

          {(selectedSensorTab === 'all' || selectedSensorTab === 'fsr') && (
            <LiveChart 
              title={`${t('gripPressure')} (FSR)`} 
              data={data}
              isDark={!isHighContrast}
              dataKeys={[
                { key: 'fsr', color: '#d97706', name: t('pressure') },
              ]}
              unit="/1000"
              calibratedDomain={[0, 1000]}
              scalePresets={[
                { label: '0 - 1000', domain: [0, 1000] },
                { label: 'Auto Fit', domain: ['auto', 'auto'] },
                { label: '0 - 4095', domain: [0, 4095] },
              ]}
              onQuickCalibrate={() => startCalibration('fsr')}
              calibrateLabel={t('tareGripPressure')}
              isCalibrated={offsets.fsr !== 0}
            />
          )}
        </div>

        {/* Session Log / Controls */}
        <div className="mb-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-lg p-5 h-auto min-h-64 flex flex-col shadow-2xs">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-slate-900 dark:text-slate-100 text-xs font-semibold uppercase tracking-wider font-mono">{t('sessionControls')}</h3>
              <div className="flex gap-1.5">
                <button onClick={exportSession} className="text-slate-400 hover:text-sky-700 dark:text-slate-500 dark:hover:text-sky-400 transition-colors p-1.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800" title="Export Session as JSON">
                  <Save size={15} />
                </button>
                <button onClick={clearData} className="text-slate-400 hover:text-slate-700 dark:text-slate-500 dark:hover:text-white transition-colors p-1.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800" title="Clear Graphs">
                  <Trash2 size={15} />
                </button>
              </div>
            </div>
            
            <div className="flex-1 flex flex-col md:flex-row gap-3">
              <div className="flex-1 flex flex-col items-center justify-center space-y-3 border border-slate-200 dark:border-slate-800 rounded-lg bg-slate-50/70 dark:bg-slate-950/40 p-4">
                {!isRecording ? (
                  <button 
                    onClick={() => {
                      audioFeedback.playStartRecording();
                      setIsRecording(true);
                      recordingBuffer.current = [];
                      recordingStartTime.current = Date.now();
                    }}
                    disabled={!isConnected}
                    className="flex items-center justify-center w-12 h-12 rounded-full bg-red-600 hover:bg-red-700 text-white transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-2xs"
                    title="Record Session"
                  >
                    <div className="w-4 h-4 bg-white rounded-full" />
                  </button>
                ) : (
                  <button 
                    onClick={() => {
                      audioFeedback.playStopRecording();
                      setIsRecording(false);
                      const duration = (Date.now() - recordingStartTime.current) / 1000;
                      const deviceType = connectionType === 'mobile' ? 'mobile' : 'pen';
                      const sessionFeatures = mlService.extractFeatures(recordingBuffer.current, deviceType);
                      const sessionId = crypto.randomUUID();

                      if (!user) {
                        // Save locally for guest clinical user so data is never lost
                        const guestSession: Session = {
                          id: sessionId,
                          userId: 'guest',
                          timestamp: Date.now(),
                          duration: duration,
                          severity: metrics.intensity,
                          stage: metrics.stage,
                          rms: sessionFeatures.rms,
                          frequency: sessionFeatures.frequency,
                          data: [...recordingBuffer.current]
                        };
                        setRecordedSessions((prev) => [guestSession, ...prev]);
                        try {
                          const existing = JSON.parse(localStorage.getItem('neurotremor_guest_sessions') || '[]');
                          localStorage.setItem('neurotremor_guest_sessions', JSON.stringify([guestSession, ...existing]));
                        } catch (e) {}
                        mlService.trainOnSession(guestSession.data, guestSession.severity);
                        recordingBuffer.current = [];
                        return;
                      }

                      const newSession: Session = {
                        id: sessionId,
                        userId: user.uid,
                        timestamp: Date.now(),
                        duration: duration,
                        severity: metrics.intensity,
                        stage: metrics.stage,
                        rms: sessionFeatures.rms,
                        frequency: sessionFeatures.frequency,
                        data: [...recordingBuffer.current]
                      };
                      
                      // Optimistically add to state and local persistent cache
                      setRecordedSessions(prev => [newSession, ...prev]);
                      try {
                        const cached = JSON.parse(localStorage.getItem(`neurotremor_cached_sessions_${user.uid}`) || '[]');
                        localStorage.setItem(`neurotremor_cached_sessions_${user.uid}`, JSON.stringify([newSession, ...cached]));
                      } catch (e) {}

                      setDoc(doc(db, 'sessions', sessionId), {
                        ...newSession,
                        data: JSON.stringify(newSession.data)
                      }).then(() => {
                        mlService.trainOnSession(newSession.data, newSession.severity);
                      }).catch(error => {
                        console.warn("Notice: Remote Firestore sync delayed, saved to local cache:", error);
                        try {
                          const pending = JSON.parse(localStorage.getItem('neurotremor_pending_sync') || '[]');
                          localStorage.setItem('neurotremor_pending_sync', JSON.stringify([...pending, newSession]));
                        } catch (e) {}
                      });
                      
                      recordingBuffer.current = [];
                    }}
                    className="flex items-center justify-center w-12 h-12 rounded-full bg-slate-800 hover:bg-slate-900 dark:bg-slate-700 dark:hover:bg-slate-600 transition-all shadow-2xs text-white"
                    title="Stop and Save Session"
                  >
                    <Square className="text-white fill-current" size={18} />
                  </button>
                )}
                <p className="text-slate-700 dark:text-slate-400 text-xs font-medium text-center">
                  {isRecording ? t('recordingSession') : t('recordCloudSession')}
                </p>
              </div>

              <div className="flex-1 flex flex-col items-center justify-center space-y-2.5 border border-slate-200 dark:border-slate-800 rounded-lg bg-slate-50/70 dark:bg-slate-950/40 p-4">
                {!isStreamingExport ? (
                  <>
                    <div className="flex gap-2 w-full max-w-[180px]">
                      <select 
                        className="flex-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-md px-2 py-1 text-xs text-slate-800 dark:text-slate-200 shadow-2xs"
                        value={exportFormat}
                        onChange={(e) => setExportFormat(e.target.value as 'csv'|'json')}
                        disabled={!isConnected}
                      >
                        <option value="csv">CSV</option>
                        <option value="json">JSON</option>
                      </select>
                      <select
                        className="flex-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-md px-2 py-1 text-xs text-slate-800 dark:text-slate-200 shadow-2xs"
                        value={exportDuration}
                        onChange={(e) => setExportDuration(Number(e.target.value))}
                        disabled={!isConnected}
                      >
                        <option value={0}>{t('continuous')}</option>
                        <option value={10}>10s</option>
                        <option value={30}>30s</option>
                        <option value={60}>1m</option>
                      </select>
                    </div>
                    <button 
                      onClick={async () => {
                        try {
                          await exportService.startStreaming(exportFormat, exportDuration, () => setIsStreamingExport(false));
                          setIsStreamingExport(true);
                        } catch (e: any) {
                          setErrorModal({ title: "Export Error", message: e.message || "Failed to start streaming." });
                        }
                      }}
                      disabled={!isConnected}
                      className="flex items-center justify-center w-10 h-10 rounded-full bg-sky-700 hover:bg-sky-800 text-white transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-2xs"
                      title="Start Real-Time Export to File"
                    >
                      <Save size={16} />
                    </button>
                    <p className="text-slate-700 dark:text-slate-400 text-xs font-medium text-center">{t('liveFileStream')}</p>
                  </>
                ) : (
                  <>
                    <div className="flex items-center justify-center w-10 h-10 rounded-full border-2 border-sky-400 animate-pulse">
                      <button 
                        onClick={() => {
                          exportService.stopStreaming();
                          setIsStreamingExport(false);
                        }}
                        className="flex items-center justify-center w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-900 dark:bg-slate-700 dark:hover:bg-slate-600 transition-all text-white"
                      >
                        <Square className="fill-current" size={14} />
                      </button>
                    </div>
                    <p className="text-sky-700 dark:text-sky-400 text-xs font-medium font-mono animate-pulse text-center">{t('writingFile')} {exportFormat.toUpperCase()}...</p>
                  </>
                )}
              </div>
            </div>
            
            {recordedSessions.length > 0 && (
              <div className="mt-4 flex-1 overflow-y-auto pr-1">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider font-mono">{t('clinicalReportHistory')}</h4>
                  <button 
                    onClick={async () => {
                      setConfirmModal({
                        title: t('confirmClearAllTitle'),
                        message: t('confirmClearAllMsg'),
                        onConfirm: async () => {
                          try {
                            for (const session of recordedSessions) {
                              await deleteDoc(doc(db, 'sessions', session.id));
                            }
                          } catch (error) {
                            console.error("Error clearing sessions", error);
                            setErrorModal({ title: "Delete Error", message: "Failed to clear some sessions." });
                          }
                        }
                      });
                    }}
                    className="text-[10px] text-slate-500 hover:text-red-600 dark:text-slate-500 dark:hover:text-red-400 transition-colors font-medium"
                  >
                    {t('clearAll')}
                  </button>
                </div>
                <div className="space-y-1.5">
                  {recordedSessions.map((session) => (
                    <div key={session.id} className="flex justify-between items-center bg-slate-50 dark:bg-slate-950/60 px-3 py-2 rounded-md text-xs border border-slate-200/80 dark:border-slate-800 group hover:border-slate-300 dark:hover:border-slate-700 transition-colors">
                      <div className="flex flex-col font-mono">
                        <span className="text-slate-800 dark:text-slate-200 font-medium">{new Date(session.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        <span className="text-slate-500 dark:text-slate-500 text-[10px]">{session.duration.toFixed(1)}s · {session.data.length} {t('points')}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-medium border ${
                          session.severity === 'Severe' ? 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/50 dark:text-rose-400 dark:border-rose-900' : 
                          session.severity === 'Moderate' ? 'bg-amber-50 text-amber-800 border-amber-200 dark:bg-amber-950/50 dark:text-amber-400 dark:border-amber-900' : 
                          'bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-400 dark:border-emerald-900'
                        }`}>
                          {session.severity === 'Severe' ? t('severe') : session.severity === 'Moderate' ? t('moderate') : t('mild')}
                        </span>
                        <div className="flex items-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <button 
                            onClick={() => setReportModalSession(session)}
                            className="p-1 text-slate-500 hover:text-sky-700 dark:text-slate-400 dark:hover:text-sky-400 transition-colors"
                            title={t('downloadReport')}
                          >
                            <FileText size={14} />
                          </button>
                          <button 
                            onClick={() => {
                              setLoadedDataset(session.data);
                              startDatasetPlayback(session.data);
                            }}
                            className="p-1 text-slate-500 hover:text-emerald-700 dark:text-slate-400 dark:hover:text-emerald-400 transition-colors"
                            title={t('replaySession')}
                          >
                            <Play size={14} fill="currentColor" />
                          </button>
                          <button 
                            onClick={async () => {
                              try {
                                await deleteDoc(doc(db, 'sessions', session.id));
                              } catch (error) {
                                console.error("Error deleting session", error);
                              }
                            }}
                            className="p-1 text-slate-500 hover:text-red-600 dark:text-slate-400 dark:hover:text-red-400 transition-colors"
                            title={t('deleteSession')}
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Instructions */}
        <div className="border-t border-slate-200 dark:border-slate-800 pt-6 mt-6">
          <h4 className="text-slate-900 dark:text-slate-100 font-semibold mb-3 text-xs uppercase tracking-wider font-mono">{t('userGuide')}</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-slate-600 dark:text-slate-400">
            <div className="bg-white dark:bg-slate-900 p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 shadow-2xs space-y-1.5">
              <strong className="text-slate-900 dark:text-slate-200 block font-semibold">{t('guideStep1Title')}</strong>
              <p className="leading-relaxed">{t('guideStep1Desc')}</p>
              <div className="bg-slate-50 dark:bg-slate-950/60 p-2 rounded border border-slate-200 dark:border-slate-800 mt-2 text-slate-600 dark:text-slate-400 text-[11px]">
                {t('guideStep1Note')}
              </div>
            </div>
            <div className="bg-white dark:bg-slate-900 p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 shadow-2xs space-y-1.5">
              <strong className="text-slate-900 dark:text-slate-200 block font-semibold">{t('guideStep2Title')}</strong>
              <p className="leading-relaxed">{t('guideStep2Desc')}</p>
            </div>
            <div className="bg-white dark:bg-slate-900 p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 shadow-2xs space-y-1.5">
              <strong className="text-slate-900 dark:text-slate-200 block font-semibold">{t('guideStep3Title')}</strong>
              <p className="leading-relaxed">{t('guideStep3Desc')}</p>
            </div>
          </div>
        </div>
        {/* Calibration Modal */}
        <CalibrationModal
          isOpen={showCalibrationModal}
          onClose={() => setShowCalibrationModal(false)}
          offsets={offsets}
          onSaveOffsets={handleSaveOffsets}
          onStartCalibration={startCalibration}
          isCalibrating={isCalibrating}
          calibrationTimeLeft={calibrationTimeLeft}
          calibrationType={calibrationType}
          isConnected={isConnected}
        />

        {/* Patient Details Modal */}
        <PatientDetailsModal
          isOpen={!!reportModalSession}
          onClose={() => setReportModalSession(null)}
          onSubmit={(details) => {
            if (reportModalSession) {
              generateClinicalReport(reportModalSession, details);
              setReportModalSession(null);
            }
          }}
          defaultAssessmentDate={reportModalSession?.timestamp}
        />

        {/* Security & Clinical Privacy Modal */}
        <SecurityPrivacyModal
          isOpen={!!securityModalTab}
          onClose={() => setSecurityModalTab(null)}
          defaultTab={securityModalTab || 'medical'}
          isDark={!isHighContrast}
        />

        {/* Clinical Compliance & Security Footer */}
        <footer className="mt-10 pt-6 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
          <div className="flex flex-col md:flex-row items-center justify-between gap-3 pb-4">
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 rounded bg-sky-700 flex items-center justify-center text-white">
                <Activity size={12} />
              </div>
              <span className="font-semibold text-slate-800 dark:text-slate-200 font-mono text-xs">NeuroTremor Enterprise Clinical Suite</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700 font-mono">v2.4 Sec-Hardened</span>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-3 text-xs">
              <button
                onClick={() => setSecurityModalTab('medical')}
                className="hover:text-amber-700 dark:hover:text-amber-400 transition-colors"
              >
                Medical Disclaimer
              </button>
              <span>·</span>
              <button
                onClick={() => setSecurityModalTab('privacy')}
                className="hover:text-sky-700 dark:hover:text-sky-400 transition-colors"
              >
                Privacy Policy
              </button>
              <span>·</span>
              <button
                onClick={() => setSecurityModalTab('cookies')}
                className="hover:text-emerald-700 dark:hover:text-emerald-400 transition-colors"
              >
                Cookies & Storage
              </button>
              <span>·</span>
              <button
                onClick={() => setSecurityModalTab('security')}
                className="hover:text-purple-700 dark:hover:text-purple-400 transition-colors"
              >
                System Security
              </button>
            </div>
          </div>

          <div className="p-3 rounded-md bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400 text-center sm:text-left mb-6">
            <strong className="text-slate-700 dark:text-slate-300">Medical & Regulatory Notice:</strong> NeuroTremor is an investigational decision-support and quantitative motion-screening utility. It is not an FDA/CE cleared diagnostic medical device. Biometric tremor scores, kinematic RMS values, and stage estimates do not constitute a definitive medical diagnosis. Consult a board-certified neurologist for diagnostic evaluation. No payment processing, commercial tracking, or third-party advertising cookies are used.
          </div>
        </footer>

        {/* Non-Intrusive Privacy & Consent Banner */}
        <ConsentBanner onOpenSecurityModal={(tab) => setSecurityModalTab(tab || 'medical')} />
      </main>
    </div>
  );
}

export default App;
